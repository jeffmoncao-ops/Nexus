"""
nexus/api/server.py
===================
FastAPI backend — bridge between the UI and the cognitive kernel.

Endpoints:
  POST /learn   -> learn a fact
  POST /chat    -> query with epistemic state
  POST /search  -> direct hippocampus search
  GET  /health  -> system health
  GET  /brains  -> status of all brains
  POST /sleep   -> Hebbian decay
  POST /web     -> force web search for a topic
"""
from __future__ import annotations

import os, time
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from nexus.core.sdr_math import MiniEmbed
from nexus.memory.hippocampus import HippocampusAsync, CONFIDENCE_THRESHOLD
from nexus.cognitive.brains import GlobalWorkspace
from nexus.cognitive.text_weaver import TextWeaver, WebBrain


class AppState:
    embed:     MiniEmbed
    hip_async: HippocampusAsync
    workspace: GlobalWorkspace
    weaver:    TextWeaver
    web_brain: WebBrain
    ready:     bool = False


_state = AppState()


def _init_state(db_path: str = "nexus_api.db") -> None:
    """Initializes (or re-initializes) global state — usable in tests."""
    global _state
    _state           = AppState()
    _state.embed     = MiniEmbed()
    _state.hip_async = HippocampusAsync(db_path=db_path)
    _state.workspace = GlobalWorkspace(
        hippocampus=_state.hip_async._hip,
        embed=_state.embed,
    )
    _state.web_brain = WebBrain(_state.workspace, timeout=4.0)
    _state.weaver    = TextWeaver(_state.workspace, _state.web_brain)
    _state.ready     = True


@asynccontextmanager
async def lifespan(app: FastAPI):
    db = os.environ.get("NEXUS_DB_PATH", "nexus_api.db")
    _init_state(db_path=db)
    print("Nexus V2 API — online.")
    yield
    _state.hip_async.close()
    print("Nexus V2 API — shutdown.")


app = FastAPI(
    title="Nexus V2 API",
    description="SDR Cognitive Kernel — no n-grams, strict epistemic state.",
    version="2.0.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)


def _require_ready():
    if not _state.ready:
        raise HTTPException(503, "System not initialized.")


class LearnRequest(BaseModel):
    text:     str
    brain_id: Optional[str] = None
    weight:   float = 1.0

class ChatRequest(BaseModel):
    message:      str
    web_fallback: bool = True

class SearchRequest(BaseModel):
    query:        str
    top_k:        int  = 5
    cross_domain: bool = True

class WebRequest(BaseModel):
    topic: str


@app.post("/learn")
async def learn(req: LearnRequest):
    _require_ready()
    if not req.text.strip():
        raise HTTPException(400, "Empty text.")
    result = _state.workspace.learn(req.text.strip(), brain_id=req.brain_id, weight=req.weight)
    return {
        "stored":   result.stored,
        "brain_id": result.brain_id,
        "row_id":   result.row_id,
        "message":  (f'Learned: "{result.text[:60]}"' if result.stored
                     else "Already know something similar (dedup)."),
    }


@app.post("/chat")
async def chat(req: ChatRequest):
    _require_ready()
    if not req.message.strip():
        raise HTTPException(400, "Empty message.")
    t0       = time.perf_counter()
    sdr      = _state.embed.encode(req.message)
    response = _state.weaver.respond(req.message, web_fallback=req.web_fallback)
    elapsed  = time.perf_counter() - t0
    result   = _state.workspace.query(req.message)
    return {
        "response":   response,
        "confident":  result.confident,
        "score":      round(result.score, 4),
        "brain_id":   result.brain_id,
        "latency_ms": round(elapsed * 1000, 1),
        "sdr_sig63":  sdr.to_hex_signature(),
    }


@app.post("/search")
async def search(req: SearchRequest):
    _require_ready()
    sdr  = _state.embed.encode(req.query)
    hits = await _state.hip_async.recall(sdr, top_k=req.top_k, cross_domain=req.cross_domain)
    return {
        "query": req.query,
        "hits":  [{"score": round(s, 4), "text": t, "brain": b} for s, t, b in hits],
        "confidence_threshold": CONFIDENCE_THRESHOLD,
    }


@app.get("/health")
async def health():
    _require_ready()
    return {"status": "online", "version": "2.0.0", "ready": _state.ready,
            "system": _state.workspace.health()}


@app.get("/brains")
async def brains():
    _require_ready()
    return {
        "count":  len(_state.workspace._brains),
        "status": _state.workspace.brain_status(),
        "brains": {bid: b.stats for bid, b in _state.workspace._brains.items()},
    }


@app.post("/sleep")
async def sleep():
    _require_ready()
    return _state.workspace.sleep()


@app.post("/web")
async def web_search(req: WebRequest):
    _require_ready()
    if not _state.web_brain.active:
        raise HTTPException(503, "WebBrain disabled.")
    text = _state.web_brain.fetch_and_learn(req.topic)
    if text:
        return {"learned": True,  "text": text[:300]}
    return    {"learned": False, "text": ""}


def run(host: str = "127.0.0.1", port: int = 8000):
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="info")
