"""
nexus/cognitive/brains.py
=========================
Specialist brains with geometric domain SDR signatures.

Key difference from v1:
  - NO keyword matching (no "if 'python' in text")
  - Each brain has a DOMAIN SDR — a geometric identity vector
  - When querying the hippocampus, the brain applies XOR of the question
    with its domain signature, filtering geometrically in 8192 dimensions.
  - This creates real cognitive perspectives, not text routing.

Strict epistemic state:
  - knows()   -> True only if Jaccard >= CONFIDENCE_THRESHOLD
  - query()   -> returns hits with explicit score
  - "I don't know" -> signaled by QueryResult.confident = False
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from nexus.core.sdr_math import MiniEmbed, SparseSDR, XORBinding, SDR_ACTIVE, SDR_SIZE
from nexus.memory.hippocampus import (
    Hippocampus, CONFIDENCE_THRESHOLD, RECALL_THRESHOLD
)


@dataclass
class QueryResult:
    """
    Result of a system query.
    confident = False is the explicit trigger for the WebBrain to act.
    """
    text:         str
    score:        float
    brain_id:     str
    confident:    bool
    cross_domain: bool = False

    def __bool__(self) -> bool:
        return self.confident


@dataclass
class LearnResult:
    """Result of a learning operation."""
    stored:   bool
    text:     str
    brain_id: str
    row_id:   int    # 0 = duplicate


class SpecialistBrain:
    """
    Specialist brain identified by its DOMAIN SDR.

    The domain_sdr is generated from the domain's definition text.
    When querying the hippocampus, the brain applies XOR domain+query
    to filter geometrically in the 8192-dimension space.
    """

    def __init__(
        self,
        brain_id:    str,
        name:        str,
        domain_text: str,
        embed:       MiniEmbed,
        hippocampus: Hippocampus,
    ):
        self.id         = brain_id
        self.name       = name
        self._embed     = embed
        self._hip       = hippocampus
        self._xor       = XORBinding(embed)
        self.domain_sdr = self._build_domain_sdr(embed, domain_text)
        self._learned   = 0
        self._queried   = 0
        self._confident = 0

    @staticmethod
    def _build_domain_sdr(embed: MiniEmbed, domain_text: str) -> SparseSDR:
        """
        Builds a rich domain SDR from the domain text tokens.
        Each token is encoded individually; bits are accumulated and
        passed through k-WTA -> 6*SDR_ACTIVE bits = more discriminative signature.
        """
        tokens   = list(set(__import__('re').findall(r'\w{3,}', domain_text.lower())))[:20]
        all_bits: set = set()
        for tok in tokens:
            sdr = embed.encode(tok)
            all_bits.update(sdr._idx)
        lst  = sorted(all_bits)
        n    = SDR_ACTIVE * 6  # 360 bits -> rich signature in 8192 space
        step = max(1, len(lst) // n)
        return SparseSDR(lst[::step][:n])

    def _domain_filter(self, query_sdr: SparseSDR) -> SparseSDR:
        """
        Applies XOR with domain SDR and k-WTA.
        'Tilts' the query vector toward the domain's region.
        """
        raw = set(query_sdr._idx) ^ set(self.domain_sdr._idx)
        if len(raw) > SDR_ACTIVE:
            lst  = sorted(raw)
            step = max(1, len(lst) // SDR_ACTIVE)
            raw  = set(lst[::step][:SDR_ACTIVE])
        return SparseSDR(raw)

    def domain_relevance(self, query_sdr: SparseSDR) -> float:
        """
        Jaccard between query and domain_sdr.
        Geometric score — does not depend on keywords.
        """
        return query_sdr.jaccard(self.domain_sdr)

    def learn(self, text: str, weight: float = 1.0) -> LearnResult:
        """Learns a fact — stores in the shared hippocampus."""
        sdr = self._embed.encode(text)
        rid = self._hip.store(sdr, text, brain=self.id, weight=weight)
        if rid > 0:
            self._learned += 1
        return LearnResult(stored=rid > 0, text=text, brain_id=self.id, row_id=rid)

    def query(self, text: str, top_k: int = 3,
              cross_domain: bool = False) -> List[QueryResult]:
        """
        Query with geometric domain filter.
        cross_domain=True: uses original query SDR (max inter-domain recall).
        cross_domain=False: applies domain filter for specialized search.
        """
        self._queried += 1
        query_sdr = self._embed.encode(text)

        if cross_domain:
            search_sdr   = query_sdr
            brain_filter = None
        else:
            search_sdr   = self._domain_filter(query_sdr)
            brain_filter = self.id

        hits = self._hip.recall(
            search_sdr, top_k=top_k,
            brain_filter=brain_filter,
            min_jaccard=RECALL_THRESHOLD,
            cross_domain=cross_domain,
        )

        results = []
        for score, text_hit, brain_hit in hits:
            confident = score >= CONFIDENCE_THRESHOLD
            if confident: self._confident += 1
            results.append(QueryResult(
                text=text_hit, score=score, brain_id=brain_hit,
                confident=confident, cross_domain=cross_domain,
            ))
        return results

    def knows(self, text: str) -> bool:
        q = self._embed.encode(text)
        f = self._domain_filter(q)
        return self._hip.knows(f)

    @property
    def stats(self) -> dict:
        facts = len(self._hip.all_facts(brain_filter=self.id))
        return {
            "id": self.id, "name": self.name, "facts": facts,
            "learned": self._learned, "queried": self._queried,
            "confident": self._confident,
        }


DEFAULT_DOMAINS: List[Dict] = [
    {
        "id":   "technology",
        "name": "Technology and Computing",
        "text": ("programming code software algorithm computer system "
                 "python javascript database network internet api server "
                 "artificial intelligence machine learning compiler memory"),
    },
    {
        "id":   "biology",
        "name": "Biology and Life Sciences",
        "text": ("cell dna rna protein evolution organism photosynthesis "
                 "mitosis meiosis genetics chromosome metabolism enzyme "
                 "virus bacteria ecosystem biodiversity genome"),
    },
    {
        "id":   "physics",
        "name": "Physics",
        "text": ("atom particle electron force energy gravity velocity "
                 "mass wave frequency heat temperature thermodynamics "
                 "electricity magnetism relativity quantum photon"),
    },
    {
        "id":   "mathematics",
        "name": "Mathematics",
        "text": ("number function equation integral derivative logarithm "
                 "probability statistics geometry algebra calculus "
                 "theorem prime matrix vector limit series"),
    },
    {
        "id":   "medicine",
        "name": "Medicine and Health",
        "text": ("disease symptom diagnosis treatment medication vaccine "
                 "infection immunity antibody organ heart lung "
                 "cancer diabetes surgery nutrition hormone epidemic"),
    },
    {
        "id":   "history",
        "name": "History",
        "text": ("war revolution empire civilization discovery colony "
                 "politics government president century democracy dictatorship "
                 "colonialism independence treaty renaissance"),
    },
    {
        "id":   "geography",
        "name": "Geography",
        "text": ("continent country capital city ocean mountain "
                 "climate biome forest territory population "
                 "migration urbanization region border"),
    },
    {
        "id":   "linguistics",
        "name": "Linguistics and Literature",
        "text": ("language grammar syntax semantics phonology morphology "
                 "text discourse communication literature poem "
                 "metaphor analogy writing author"),
    },
]


class GlobalWorkspace:
    """
    Multi-brain orchestrator with shared hippocampus.

    Processing flow:
      1. learn(text) -> embed -> store in hippocampus -> propagate to relevant brains
      2. query(text) -> embed -> epistemic state:
           a. knows() True  -> returns best hit with brain of origin
           b. knows() False -> returns QueryResult(confident=False)
                               explicit trigger for WebBrain
      3. Brains consulted in parallel via geometric domain_relevance
      4. sleep() -> Hebbian decay in hippocampus
    """

    def __init__(
        self,
        hippocampus: Hippocampus,
        embed:       MiniEmbed,
        domains:     Optional[List[Dict]] = None,
    ):
        self._hip    = hippocampus
        self._embed  = embed
        self._xor    = XORBinding(embed)
        self._brains: Dict[str, SpecialistBrain] = {}
        self._stats  = {
            "learned": 0, "queries": 0,
            "confident_hits": 0, "uncertain_hits": 0,
            "propagations": 0, "sleep_cycles": 0,
        }

        for d in (domains if domains is not None else DEFAULT_DOMAINS):
            self._brains[d["id"]] = SpecialistBrain(
                brain_id=d["id"], name=d["name"],
                domain_text=d["text"], embed=embed, hippocampus=hippocampus,
            )

    def learn(self, text: str, brain_id: Optional[str] = None,
              weight: float = 1.0) -> LearnResult:
        """
        Learns a fact.
        If brain_id not specified, propagates to the geometrically closest brain.
        """
        sdr    = self._embed.encode(text)
        target = brain_id or self._best_brain(sdr)

        if target and target in self._brains:
            result = self._brains[target].learn(text, weight)
        else:
            rid    = self._hip.store(sdr, text, brain="core", weight=weight)
            result = LearnResult(stored=rid > 0, text=text, brain_id="core", row_id=rid)

        if result.stored:
            self._stats["learned"] += 1
            if target and target != brain_id:
                self._stats["propagations"] += 1

        return result

    def query(self, text: str, top_k: int = 3,
              cross_domain: bool = True) -> QueryResult:
        """
        Queries the system with explicit epistemic state.

        Returns:
          - QueryResult(confident=True)  if Jaccard >= CONFIDENCE_THRESHOLD
          - QueryResult(confident=False) if nothing similar enough
            -> this is the trigger for the WebBrain
        """
        self._stats["queries"] += 1
        query_sdr = self._embed.encode(text)

        hits = self._hip.recall(
            query_sdr, top_k=top_k,
            min_jaccard=RECALL_THRESHOLD, cross_domain=cross_domain
        )

        if hits:
            score, text_hit, brain_hit = hits[0]
            confident = score >= CONFIDENCE_THRESHOLD
            self._stats["confident_hits" if confident else "uncertain_hits"] += 1
            return QueryResult(text=text_hit, score=score,
                               brain_id=brain_hit, confident=confident,
                               cross_domain=cross_domain)

        self._stats["uncertain_hits"] += 1
        return QueryResult(text="", score=0.0, brain_id="", confident=False)

    def query_multi(self, text: str, top_k: int = 3) -> List[QueryResult]:
        """Queries all brains and returns results sorted by score."""
        self._stats["queries"] += 1
        query_sdr = self._embed.encode(text)
        results   = []
        for brain in self._brains.values():
            if brain.domain_relevance(query_sdr) < 0.02:
                continue
            results.extend(brain.query(text, top_k=top_k, cross_domain=False))
        results.sort(key=lambda r: -r.score)
        return results[:top_k]

    def add_brain(self, brain_id: str, name: str,
                  domain_text: str) -> SpecialistBrain:
        """Adds a custom brain — inherits the same hippocampus."""
        brain = SpecialistBrain(
            brain_id=brain_id, name=name, domain_text=domain_text,
            embed=self._embed, hippocampus=self._hip,
        )
        self._brains[brain_id] = brain
        return brain

    def remove_brain(self, brain_id: str) -> bool:
        if brain_id in self._brains:
            del self._brains[brain_id]
            return True
        return False

    def sleep(self) -> dict:
        """Hebbian decay and consolidation."""
        self._stats["sleep_cycles"] += 1
        affected = self._hip.sleep_decay()
        return {"sleep_cycle": self._stats["sleep_cycles"], "decayed_facts": affected}

    def brain_status(self) -> str:
        lines = ["Active brains:"]
        for b in self._brains.values():
            s = b.stats
            lines.append(
                f"  [{s['id']:12s}] {s['name']:35s} "
                f"facts={s['facts']:4d}  learned={s['learned']:4d}  "
                f"confident={s['confident']:4d}"
            )
        return "\n".join(lines)

    def health(self) -> dict:
        return {
            "hippocampus": self._hip.stats(),
            "brains":      {bid: b.stats for bid, b in self._brains.items()},
            "stats":       self._stats,
        }

    def _best_brain(self, sdr: SparseSDR) -> Optional[str]:
        """Returns the brain with the highest geometric domain_relevance."""
        best_id, best_score = None, 0.0
        for bid, brain in self._brains.items():
            rel = brain.domain_relevance(sdr)
            if rel > best_score:
                best_score, best_id = rel, bid
        return best_id if best_score > 0.02 else None
