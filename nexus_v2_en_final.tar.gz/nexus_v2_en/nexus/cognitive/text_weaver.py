"""
nexus/cognitive/text_weaver.py
==============================
TextWeaver — output formatting based on epistemic state.

Does NOT generate text statistically. Does NOT use n-grams.

Principle: the system only says what it knows.
  - If confident=True  -> formats the retrieved memory
  - If confident=False -> returns "Insufficient data"
                          (trigger for WebBrain)
  - After learning via WebBrain -> reformats with new knowledge
"""
from __future__ import annotations

import re
from typing import Optional

from nexus.cognitive.brains import GlobalWorkspace, QueryResult

_INSUFFICIENT = "Insufficient data in local memory."
_LEARNED      = 'Learned: "{text}"'
_DUPLICATE    = '[dedup] Already know something similar: "{text}"'


class TextWeaver:
    """Formats responses based on QueryResult. Integrates WebBrain optionally."""

    def __init__(self, workspace: GlobalWorkspace,
                 web_brain: Optional["WebBrain"] = None):
        self._ws  = workspace
        self._web = web_brain

    def respond(self, query: str, web_fallback: bool = True) -> str:
        """
        Processes a query and returns a text response.

        Flow:
          1. query_sdr -> hippocampus
          2. confident=True  -> format hit
          3. confident=False -> if web_brain available, fetch and learn
                             -> reformat or return "Insufficient data"
        """
        result = self._ws.query(query)

        if result.confident:
            return self._format_hit(result)

        if web_fallback and self._web is not None:
            learned_text = self._web.fetch_and_learn(query)
            if learned_text:
                result2 = self._ws.query(query)
                if result2.confident:
                    return f"[Web] {self._format_hit(result2)}"
                return f"[Web] Just learned: {learned_text[:300]}"

        return _INSUFFICIENT

    def learn_and_respond(self, text: str) -> str:
        """Learns a fact and returns confirmation."""
        result = self._ws.learn(text)
        if result.row_id == 0:
            best = self._ws.query(text)
            return _DUPLICATE.format(text=best.text[:60] if best.text else text[:60])
        return _LEARNED.format(text=text[:80])

    def _format_hit(self, result: QueryResult) -> str:
        """Formats retrieved text — no invention, only what's in memory."""
        text = result.text.strip()
        if not text:
            return _INSUFFICIENT
        if text and text[-1] not in ".!?":
            text += "."
        origin = f" [{result.brain_id}]" if result.brain_id else ""
        return f"{text}{origin}"


class WebBrain:
    """
    Fetches external information and feeds the GlobalWorkspace.
    Activated ONLY when the system has no confident answer.
    """

    def __init__(self, workspace: GlobalWorkspace, timeout: float = 4.0):
        self._ws      = workspace
        self._timeout = timeout
        self.active   = True

    def fetch_and_learn(self, query: str) -> Optional[str]:
        """
        Fetches from Wikipedia EN and learns in the hippocampus.
        Returns learned text or None if failed.
        Synchronous — uses urllib with no extra dependencies.
        """
        if not self.active:
            return None

        words = sorted(re.findall(r'\w{4,}', query.lower()), key=len, reverse=True)
        if not words:
            return None
        topic = words[0]

        try:
            import urllib.request, json, urllib.parse
            encoded = urllib.parse.quote(topic)
            url     = f"https://en.wikipedia.org/api/rest_v1/page/summary/{encoded}"
            req     = urllib.request.Request(url, headers={"User-Agent": "NexusV2/1.0"})
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                data    = json.loads(resp.read().decode())
                extract = data.get("extract", "").strip()
                if extract and len(extract) > 30:
                    self._ws.learn(extract, weight=2.0)
                    return extract
        except Exception:
            pass
        return None
