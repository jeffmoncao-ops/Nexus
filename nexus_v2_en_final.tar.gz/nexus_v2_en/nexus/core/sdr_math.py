"""
nexus/core/sdr_math.py
======================
Pure SDR mathematics. Zero external dependencies. Zero text generation.

Contains:
  - SparseSDR   : sparse 8192-bit representation
  - MiniEmbed   : deterministic text -> SDR encoder
  - XORBinding  : directional SVO binding with k-WTA
  - VecOps      : vector operations with numpy fallback
"""
from __future__ import annotations
import array, hashlib, math, re, struct, unicodedata
from typing import Dict, FrozenSet, List, Optional, Tuple

SDR_SIZE   = 8192
SDR_ACTIVE = 60
SDR_SEED   = 0xDEAD_BEEF

ZONE_SEM = (0,    4096)
ZONE_CTX = (4096, 6144)
ZONE_VAL = (6144, 8192)

_STOP_EN: FrozenSet[str] = frozenset({
    "a","an","the","is","it","its","in","on","at","to","of","for","and",
    "or","but","not","with","this","that","was","are","be","been","have",
    "has","had","do","does","did","will","would","could","should","may",
    "might","can","from","by","as","if","so","there","their","they","them",
    "we","us","our","you","your","he","him","his","she","her","i","my",
})


class SparseSDR:
    """
    Sparse SDR: stores only the INDICES of active bits via array('H').
    Immutable after creation. All operations return new objects.
    """
    __slots__ = ("_idx",)

    def __init__(self, indices=None):
        if indices is None:
            self._idx = array.array("H")
        elif isinstance(indices, array.array):
            self._idx = indices
        else:
            self._idx = array.array("H", sorted(int(i) % SDR_SIZE for i in indices))

    def __or__(self, other):  return SparseSDR(set(self._idx) | set(other._idx))
    def __and__(self, other): return SparseSDR(set(self._idx) & set(other._idx))
    def __xor__(self, other): return SparseSDR(set(self._idx) ^ set(other._idx))
    def __len__(self):        return len(self._idx)
    def __repr__(self):
        return f"SparseSDR(active={len(self._idx)}, density={len(self._idx)/SDR_SIZE:.2%})"

    def jaccard(self, other: "SparseSDR") -> float:
        a, b = set(self._idx), set(other._idx)
        if not a and not b: return 1.0
        u = len(a | b)
        return len(a & b) / u if u else 0.0

    def overlap_score(self, other: "SparseSDR") -> float:
        a = set(self._idx)
        if not a: return 0.0
        return len(a & set(other._idx)) / len(a)

    def to_hex_signature(self) -> int:
        """[L1] Compresses into 127 bits for AND bitwise SQL filter."""
        val = 0
        for bit in self._idx:
            slot = int(hashlib.md5(str(bit).encode()).hexdigest(), 16) % 63
            val |= (1 << slot)
        for bit in self._idx:
            slot = int(hashlib.sha256(str(bit).encode()).hexdigest(), 16) % 63
            val |= (1 << (63 + slot))
        return val & ((1 << 63) - 1)

    def to_blob(self) -> bytes:
        """[L2] Serializes active indices to binary BLOB."""
        if not self._idx: return b""
        return struct.pack(f">{len(self._idx)}H", *self._idx)

    @classmethod
    def from_blob(cls, blob: bytes) -> "SparseSDR":
        """[L2] Restores from BLOB."""
        if not blob: return cls([])
        count = len(blob) // 2
        return cls(struct.unpack(f">{count}H", blob))

    def to_list(self) -> List[int]: return list(self._idx)

    @classmethod
    def from_list(cls, lst: List[int]) -> "SparseSDR": return cls(lst)


try:
    import numpy as _np
    HAS_NUMPY = True
except ImportError:
    _np = None
    HAS_NUMPY = False


class VecOps:
    """Vector operations with pure Python fallback."""

    @staticmethod
    def dot(a, b) -> float:
        if HAS_NUMPY: return float(_np.dot(a, b))
        return sum(x * y for x, y in zip(a, b))

    @staticmethod
    def norm(v) -> float:
        if HAS_NUMPY: return float(_np.linalg.norm(v))
        return math.sqrt(sum(x * x for x in v))

    @staticmethod
    def cosine(a, b) -> float:
        n = VecOps.norm(a) * VecOps.norm(b)
        return VecOps.dot(a, b) / n if n > 0 else 0.0

    @staticmethod
    def sdr_to_dense(sdr: SparseSDR):
        if HAS_NUMPY:
            v = _np.zeros(SDR_SIZE, dtype=_np.float32)
            if sdr._idx: v[list(sdr._idx)] = 1.0
            return v
        v = [0.0] * SDR_SIZE
        for i in sdr._idx: v[i] = 1.0
        return v


class MiniEmbed:
    """
    Deterministic text -> SparseSDR encoder.
    Same input always produces the same SDR.
    Never generates text. No mutable per-token state.

    Pipeline:
      1. Normalize (lowercase, remove accents)
      2. Tokenize removing stopwords
      3. For each token, generate bits in each zone via SHA-256
      4. k-WTA to keep exactly SDR_ACTIVE bits
    """

    def __init__(self, seed: int = SDR_SEED):
        self._seed  = seed
        self._cache: Dict[str, SparseSDR] = {}

    def _normalize(self, text: str) -> str:
        text = text.lower().strip()
        text = unicodedata.normalize("NFD", text)
        return "".join(c for c in text if unicodedata.category(c) != "Mn")

    def _tokenize(self, text: str) -> List[str]:
        words = re.findall(r"\w{2,}", self._normalize(text))
        return [w for w in words if w not in _STOP_EN] or words[:5]

    def _token_bits(self, token: str, zone_start: int,
                    zone_end: int, n_bits: int) -> List[int]:
        zone_size = zone_end - zone_start
        bits: set = set()
        salt = 0
        while len(bits) < n_bits:
            key = f"{self._seed}:{token}:{salt}".encode()
            h   = int(hashlib.sha256(key).hexdigest(), 16)
            for shift in range(0, 256, 12):
                if len(bits) >= n_bits: break
                bits.add(zone_start + (h >> shift) % zone_size)
            salt += 1
        return sorted(bits)[:n_bits]

    def encode(self, text: str) -> SparseSDR:
        if text in self._cache: return self._cache[text]

        tokens = self._tokenize(text)
        if not tokens: tokens = [text[:32]]

        bits_sem, bits_ctx, bits_val = 24, 18, 18
        all_bits: List[int] = []

        # Semantic zone: accumulate bits from all tokens
        sem_pool: set = set()
        for tok in tokens:
            sem_pool.update(self._token_bits(tok, *ZONE_SEM, bits_sem))
        sem_sorted = sorted(sem_pool)
        step = max(1, len(sem_sorted) // bits_sem)
        all_bits.extend(sem_sorted[::step][:bits_sem])

        # Context zone: hash of full normalized text
        ctx_key = self._normalize(text)[:64]
        all_bits.extend(self._token_bits(ctx_key, *ZONE_CTX, bits_ctx))

        # Valence zone: simple polarity detection
        pos = any(w in tokens for w in ["good","great","correct","yes","true","positive","right"])
        neg = any(w in tokens for w in ["bad","error","false","no","negative","problem","wrong"])
        all_bits.extend(self._token_bits(f"pos:{pos}:neg:{neg}", *ZONE_VAL, bits_val))

        unique = sorted(set(all_bits))
        while len(unique) < SDR_ACTIVE:
            extra  = self._token_bits(f"pad:{len(unique)}", 0, SDR_SIZE, 1)
            unique = sorted(set(unique) | set(extra))
        if len(unique) > SDR_ACTIVE:
            step2  = max(1, len(unique) // SDR_ACTIVE)
            unique = unique[::step2][:SDR_ACTIVE]

        sdr = SparseSDR(unique)
        self._cache[text] = sdr
        return sdr

    def similarity(self, a: str, b: str) -> float:
        return self.encode(a).jaccard(self.encode(b))


class XORBinding:
    """
    Encodes S-V-O relations as SDR via XOR with cyclic permutation.
    Avoids commutativity: bind(A,R,B) != bind(B,R,A).
    k-WTA maintains strict sparsity at SDR_ACTIVE bits.
    """

    def __init__(self, embed: MiniEmbed):
        self._embed    = embed
        self._bindings: List[Tuple[SparseSDR, str, str, str]] = []
        self._rel_cache: Dict[str, SparseSDR] = {}

    def _rel_sdr(self, rel: str) -> SparseSDR:
        if rel not in self._rel_cache:
            self._rel_cache[rel] = self._embed.encode(f"__REL__{rel}__")
        return self._rel_cache[rel]

    def bind(self, subj: str, rel: str, obj: str) -> SparseSDR:
        """Creates directional SVO binding."""
        s = self._embed.encode(subj)
        r = self._rel_sdr(rel)
        o = self._embed.encode(obj)
        s_idx = {(i + 1) % SDR_SIZE for i in s._idx}
        o_idx = {(i - 1) % SDR_SIZE for i in o._idx}
        bound = s_idx ^ set(r._idx) ^ o_idx
        if len(bound) > SDR_ACTIVE:
            lst   = sorted(bound)
            step  = max(1, len(lst) // SDR_ACTIVE)
            bound = set(lst[::step][:SDR_ACTIVE])
        sdr = SparseSDR(bound)
        self._bindings.append((sdr, subj, rel, obj))
        return sdr

    def unbind(self, subj: str, rel: str,
               top_k: int = 3, min_overlap: float = 0.02) -> List[Tuple[float, str]]:
        """Given subject + relation, finds objects via reverse XOR."""
        s     = self._embed.encode(subj)
        r     = self._rel_sdr(rel)
        query = s ^ r
        results = []
        for bound, _, _, b_obj in self._bindings:
            candidate = bound ^ query
            score     = candidate.overlap_score(self._embed.encode(b_obj))
            if score >= min_overlap:
                results.append((score, b_obj))
        return sorted(results, reverse=True)[:top_k]
