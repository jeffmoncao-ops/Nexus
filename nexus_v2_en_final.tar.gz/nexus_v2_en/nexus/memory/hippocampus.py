"""
nexus/memory/hippocampus.py
===========================
Unified Hippocampus — single source of truth for the entire system.

L1/L2 architecture:
  L1 — 127-bit AND bitwise SQL filter  -> O(1) with index
  L2 — exact 8192-bit Jaccard in Python -> semantic refinement

No FTS5. No text as primary index.
Text is metadata attached to the SDR BLOB.

Schema:
  id            : PK autoincrement
  sdr_63bit     : INTEGER  -- L1 signature (127 bits, stored as 63-bit for SQLite)
  sdr_blob      : BLOB     -- full 8192-bit SDR serialized
  text_meta     : TEXT     -- original text (metadata, not index)
  brain_origin  : TEXT     -- which brain stored it
  temporal_block: INTEGER  -- time bucket (Unix hour // 3600)
  weight        : REAL     -- Hebbian weight [0.01 .. 5.0]
  access_count  : INTEGER  -- how many times retrieved
  ts            : REAL     -- Unix timestamp
"""
from __future__ import annotations

import asyncio, math, sqlite3, time
from typing import List, Optional, Tuple

from nexus.core.sdr_math import SparseSDR

RECALL_BOOST         = 0.15
DECAY_RATE           = 0.998
DECAY_FLOOR          = 0.01
INIT_WEIGHT          = 1.0
CONFIDENCE_THRESHOLD = 0.25
RECALL_THRESHOLD     = 0.05


class Hippocampus:
    """
    Synchronous hippocampus (sqlite3 with check_same_thread=False).
    Uses a persistent connection — avoids the multiple :memory: bug.
    """

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self._conn   = sqlite3.connect(db_path, check_same_thread=False)
        self._setup()

    def _setup(self) -> None:
        self._conn.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=NORMAL;
            CREATE TABLE IF NOT EXISTS hippocampus (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                sdr_63bit       INTEGER NOT NULL,
                sdr_blob        BLOB    NOT NULL,
                text_meta       TEXT    NOT NULL DEFAULT '',
                brain_origin    TEXT    NOT NULL DEFAULT 'core',
                temporal_block  INTEGER NOT NULL,
                weight          REAL    NOT NULL DEFAULT 1.0,
                access_count    INTEGER NOT NULL DEFAULT 0,
                ts              REAL    NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_l1      ON hippocampus(sdr_63bit);
            CREATE INDEX IF NOT EXISTS idx_weight  ON hippocampus(weight DESC);
            CREATE INDEX IF NOT EXISTS idx_brain   ON hippocampus(brain_origin);
            CREATE INDEX IF NOT EXISTS idx_temporal ON hippocampus(temporal_block DESC);
        """)
        self._conn.commit()

    def store(self, sdr: SparseSDR, text: str,
              brain: str = "core", weight: float = INIT_WEIGHT) -> int:
        """
        Stores SDR + text metadata.
        Returns inserted id (> 0) or 0 if exact duplicate.
        """
        existing = self._conn.execute(
            "SELECT id FROM hippocampus WHERE text_meta = ? LIMIT 1", (text,)
        ).fetchone()
        if existing:
            return 0

        cur = self._conn.execute(
            "INSERT INTO hippocampus "
            "(sdr_63bit, sdr_blob, text_meta, brain_origin, "
            " temporal_block, weight, access_count, ts) "
            "VALUES (?, ?, ?, ?, ?, ?, 0, ?)",
            (sdr.to_hex_signature(), sdr.to_blob(), text, brain,
             int(time.time() / 3600), weight, time.time())
        )
        self._conn.commit()
        return cur.lastrowid

    def recall(self, query_sdr: SparseSDR,
               top_k: int = 5,
               brain_filter: Optional[str] = None,
               min_jaccard: float = RECALL_THRESHOLD,
               cross_domain: bool = True) -> List[Tuple[float, str, str]]:
        """
        Retrieves relevant memories.
        Returns list of (jaccard_score, text_meta, brain_origin) sorted by score desc.

        L1: SQL bitwise AND filters candidates (O(1) via index).
        L2: exact 8192-bit Jaccard in Python refines results.
        """
        sig63 = query_sdr.to_hex_signature()
        if sig63 == 0:
            return []

        current_block = int(time.time() / 3600)
        if brain_filter and not cross_domain:
            rows = self._conn.execute("""
                SELECT id, sdr_blob, text_meta, brain_origin, weight, temporal_block
                FROM hippocampus
                WHERE (sdr_63bit & ?) > 0 AND brain_origin = ?
                ORDER BY weight * (1.0 / (1.0 + (? - temporal_block))) DESC
                LIMIT 100
            """, (sig63, brain_filter, current_block)).fetchall()
        else:
            rows = self._conn.execute("""
                SELECT id, sdr_blob, text_meta, brain_origin, weight, temporal_block
                FROM hippocampus
                WHERE (sdr_63bit & ?) > 0
                ORDER BY weight * (1.0 / (1.0 + (? - temporal_block))) DESC
                LIMIT 100
            """, (sig63, current_block)).fetchall()

        if not rows:
            return []

        results: List[Tuple[float, str, str]] = []
        for row_id, blob, text, brain, weight, _ in rows:
            if not blob: continue
            j = query_sdr.jaccard(SparseSDR.from_blob(blob))
            if j < min_jaccard: continue
            results.append((j * weight, text, brain))

        results.sort(key=lambda x: -x[0])
        top = results[:top_k]

        for _, text, _ in top:
            self._conn.execute("""
                UPDATE hippocampus
                SET weight = MIN(5.0, weight + ?), access_count = access_count + 1
                WHERE text_meta = ?
            """, (RECALL_BOOST, text))
        if top:
            self._conn.commit()

        return top

    def best_match(self, query_sdr: SparseSDR,
                   brain_filter: Optional[str] = None,
                   cross_domain: bool = True) -> Optional[Tuple[float, str, str]]:
        hits = self.recall(query_sdr, top_k=1,
                           brain_filter=brain_filter, cross_domain=cross_domain)
        return hits[0] if hits else None

    def knows(self, query_sdr: SparseSDR,
              threshold: float = CONFIDENCE_THRESHOLD) -> bool:
        hit = self.best_match(query_sdr)
        return hit is not None and hit[0] >= threshold

    def sleep_decay(self) -> int:
        """Applies Hebbian decay. Returns number of facts affected."""
        cur = self._conn.execute("""
            UPDATE hippocampus
            SET weight = MAX(?, weight * ?)
            WHERE weight > ?
        """, (DECAY_FLOOR, DECAY_RATE, DECAY_FLOOR))
        self._conn.commit()
        return cur.rowcount

    def stats(self) -> dict:
        total    = self._conn.execute("SELECT COUNT(*) FROM hippocampus").fetchone()[0]
        by_brain = dict(self._conn.execute(
            "SELECT brain_origin, COUNT(*) FROM hippocampus GROUP BY brain_origin"
        ).fetchall())
        avg_w = self._conn.execute("SELECT AVG(weight) FROM hippocampus").fetchone()[0] or 0.0
        return {"total": total, "by_brain": by_brain, "avg_weight": round(avg_w, 4)}

    def all_facts(self, brain_filter: Optional[str] = None) -> List[str]:
        if brain_filter:
            rows = self._conn.execute(
                "SELECT text_meta FROM hippocampus WHERE brain_origin=? ORDER BY ts DESC",
                (brain_filter,)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT text_meta FROM hippocampus ORDER BY ts DESC"
            ).fetchall()
        return [r[0] for r in rows]

    def raw_select(self, sql: str, params: tuple = ()) -> list:
        """Direct SELECT — used in state-validation tests."""
        return self._conn.execute(sql, params).fetchall()

    def close(self) -> None:
        self._conn.close()


class HippocampusAsync:
    """
    Async wrapper around the synchronous Hippocampus.
    Uses asyncio.Lock for safety in async environments.
    Does not use aiosqlite (avoids the multiple :memory: connection bug).
    """

    def __init__(self, db_path: str = "nexus_hippocampus.db"):
        self._hip  = Hippocampus(db_path=db_path)
        self._lock = asyncio.Lock()

    async def store(self, sdr: SparseSDR, text: str,
                    brain: str = "core", weight: float = INIT_WEIGHT) -> int:
        async with self._lock:
            return self._hip.store(sdr, text, brain, weight)

    async def recall(self, query_sdr: SparseSDR,
                     top_k: int = 5,
                     brain_filter: Optional[str] = None,
                     min_jaccard: float = RECALL_THRESHOLD,
                     cross_domain: bool = True) -> List[Tuple[float, str, str]]:
        async with self._lock:
            return self._hip.recall(query_sdr, top_k, brain_filter,
                                    min_jaccard, cross_domain)

    async def knows(self, query_sdr: SparseSDR,
                    threshold: float = CONFIDENCE_THRESHOLD) -> bool:
        async with self._lock:
            return self._hip.knows(query_sdr, threshold)

    async def sleep_decay(self) -> int:
        async with self._lock:
            return self._hip.sleep_decay()

    async def stats(self) -> dict:
        async with self._lock:
            return self._hip.stats()

    def close(self) -> None:
        self._hip.close()
