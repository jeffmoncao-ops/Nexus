"""
tests/test_nexus_v2.py
======================
PyTest suite with real state validation.

Principles:
  - Direct SELECT on SQLite to verify what was actually written
  - No "len >= 0" — every assertion has a measurable criterion
  - Real FastAPI E2E test with TestClient
  - Each test is independent (fixture with isolated db)
"""
import asyncio, math, time, pytest

from nexus.core.sdr_math import (
    SparseSDR, MiniEmbed, XORBinding, VecOps,
    SDR_SIZE, SDR_ACTIVE, HAS_NUMPY,
)
from nexus.memory.hippocampus import (
    Hippocampus, HippocampusAsync,
    CONFIDENCE_THRESHOLD, RECALL_THRESHOLD,
)
from nexus.cognitive.brains import (
    GlobalWorkspace, SpecialistBrain, QueryResult, DEFAULT_DOMAINS,
)
from nexus.cognitive.text_weaver import TextWeaver, WebBrain
from nexus import Nexus


@pytest.fixture
def embed():  return MiniEmbed()

@pytest.fixture
def hip():    return Hippocampus(db_path=":memory:")

@pytest.fixture
def workspace(embed, hip): return GlobalWorkspace(hippocampus=hip, embed=embed)

@pytest.fixture
def nexus():  return Nexus(db_path=":memory:", web_enabled=False)


class TestSparseSDR:

    def test_create_correct_bits(self):
        sdr = SparseSDR(list(range(0, 120, 2)))
        assert len(sdr._idx) == 60

    def test_deterministic_from_same_input(self):
        a = SparseSDR([1, 10, 100])
        b = SparseSDR([1, 10, 100])
        assert list(a._idx) == list(b._idx)

    def test_jaccard_identical(self):
        s = SparseSDR(list(range(60)))
        assert s.jaccard(s) == pytest.approx(1.0)

    def test_jaccard_disjoint(self):
        a = SparseSDR(list(range(0, 60)))
        b = SparseSDR(list(range(60, 120)))
        assert a.jaccard(b) == pytest.approx(0.0)

    def test_jaccard_partial(self):
        a = SparseSDR(list(range(0, 60)))
        b = SparseSDR(list(range(30, 90)))
        j = a.jaccard(b)
        assert 0.0 < j < 1.0
        assert j == pytest.approx(30 / 90, abs=0.01)

    def test_xor_is_symmetric(self):
        a = SparseSDR(list(range(0, 60)))
        b = SparseSDR(list(range(30, 90)))
        assert (a ^ b).jaccard(b ^ a) == pytest.approx(1.0)

    def test_blob_roundtrip_exact(self):
        original = SparseSDR(list(range(0, 120, 2)))
        restored = SparseSDR.from_blob(original.to_blob())
        assert set(original._idx) == set(restored._idx)

    def test_blob_empty_roundtrip(self):
        empty    = SparseSDR([])
        restored = SparseSDR.from_blob(empty.to_blob())
        assert len(restored._idx) == 0

    def test_lsh_signature_in_range(self):
        sdr = SparseSDR(list(range(60)))
        sig = sdr.to_hex_signature()
        assert 0 < sig < (1 << 63)

    def test_lsh_different_sdrs_different_sigs(self):
        a = SparseSDR(list(range(0, 60)))
        b = SparseSDR(list(range(4000, 4060)))
        assert a.to_hex_signature() != b.to_hex_signature()

    def test_overlap_score(self):
        a = SparseSDR(list(range(60)))
        b = SparseSDR(list(range(0, 30)))
        assert b.overlap_score(a) == pytest.approx(1.0)
        assert a.overlap_score(b) == pytest.approx(0.5)


class TestMiniEmbed:

    def test_encode_returns_sdr(self, embed):
        sdr = embed.encode("photosynthesis")
        assert isinstance(sdr, SparseSDR)

    def test_encode_exact_active_bits(self, embed):
        sdr = embed.encode("photosynthesis converts light into glucose")
        assert len(sdr._idx) == SDR_ACTIVE

    def test_encode_deterministic(self, embed):
        a = embed.encode("hello world")
        b = embed.encode("hello world")
        assert set(a._idx) == set(b._idx)

    def test_similar_texts_higher_jaccard(self, embed):
        j_similar  = embed.similarity("photosynthesis plant light", "photosynthesis light glucose")
        j_distinct = embed.similarity("photosynthesis plant",       "football goal crowd")
        assert j_similar > j_distinct

    def test_all_bits_in_valid_range(self, embed):
        sdr = embed.encode("boundary test for bits")
        assert all(0 <= i < SDR_SIZE for i in sdr._idx)

    def test_empty_string_handled(self, embed):
        sdr = embed.encode("")
        assert len(sdr._idx) > 0


class TestXORBinding:

    def test_bind_returns_sdr(self, embed):
        xb = XORBinding(embed)
        assert isinstance(xb.bind("cat", "is", "animal"), SparseSDR)

    def test_kwta_respects_active_limit(self, embed):
        xb = XORBinding(embed)
        b  = xb.bind("programmer", "creates", "code")
        assert len(b._idx) <= SDR_ACTIVE

    def test_directional_svo_not_commutative(self, embed):
        xb = XORBinding(embed)
        b1 = xb.bind("cat", "chases", "mouse")
        b2 = xb.bind("mouse", "chases", "cat")
        assert set(b1._idx) != set(b2._idx), "HDCRoles failed: binding is not directional"

    def test_unbind_finds_candidates(self, embed):
        xb = XORBinding(embed)
        xb.bind("paris",  "capital_of", "france")
        xb.bind("berlin", "capital_of", "germany")
        r_paris  = xb.unbind("paris",  "capital_of", min_overlap=0.01)
        r_berlin = xb.unbind("berlin", "capital_of", min_overlap=0.01)
        assert len(r_paris)  > 0, "unbind paris returned empty"
        assert len(r_berlin) > 0, "unbind berlin returned empty"
        assert r_paris[0][0]  > 0
        assert r_berlin[0][0] > 0


class TestHippocampus:

    def test_store_returns_positive_rowid(self, embed, hip):
        sdr = embed.encode("photosynthesis")
        rid = hip.store(sdr, "photosynthesis converts light into glucose", brain="biology")
        assert rid > 0

    def test_duplicate_text_returns_zero(self, embed, hip):
        sdr  = embed.encode("photosynthesis")
        text = "photosynthesis converts light into glucose"
        hip.store(sdr, text)
        assert hip.store(sdr, text) == 0

    def test_stored_blob_is_exact_sdr(self, embed, hip):
        """Direct SELECT — verifies the stored BLOB restores the original SDR."""
        original = embed.encode("python is an interpreted programming language")
        rid      = hip.store(original, "python is an interpreted programming language",
                              brain="technology")
        assert rid > 0
        row = hip.raw_select(
            "SELECT sdr_blob, text_meta, brain_origin FROM hippocampus WHERE id=?", (rid,)
        )
        assert len(row) == 1
        blob, text, brain = row[0]
        restored = SparseSDR.from_blob(blob)
        assert set(restored._idx) == set(original._idx)
        assert text  == "python is an interpreted programming language"
        assert brain == "technology"

    def test_recall_returns_stored_fact(self, embed, hip):
        text = "mitosis is the cell division that generates identical cells"
        hip.store(embed.encode("mitosis cell division"), text, brain="biology")
        hits = hip.recall(embed.encode("cell division mitosis"), top_k=3, min_jaccard=0.05)
        assert len(hits) > 0
        assert text in [h[1] for h in hits]

    def test_recall_scores_above_threshold(self, embed, hip):
        text = "e=mc2 is Einstein's relativity equation"
        hip.store(embed.encode("relativity mass energy"), text)
        hits = hip.recall(embed.encode("relativity mass energy"), top_k=5, min_jaccard=0.05)
        for score, _, _ in hits:
            assert score >= 0.05

    def test_knows_true_when_confident(self, embed, hip):
        text = "quicksort is an efficient sorting algorithm"
        hip.store(embed.encode(text), text, weight=3.0)
        assert hip.knows(embed.encode(text), threshold=CONFIDENCE_THRESHOLD)

    def test_knows_false_when_empty(self, hip, embed):
        assert not hip.knows(embed.encode("topological superconductor zero temperature"))

    def test_hebbian_reinforcement_increases_weight(self, embed, hip):
        text = "eukaryotic cell has a membrane-bound nucleus"
        hip.store(embed.encode("eukaryotic cell nucleus"), text)
        w0 = hip.raw_select("SELECT weight FROM hippocampus WHERE text_meta=?", (text,))[0][0]
        hip.recall(embed.encode("eukaryotic cell nucleus"), top_k=1)
        w1 = hip.raw_select("SELECT weight FROM hippocampus WHERE text_meta=?", (text,))[0][0]
        assert w1 > w0, f"Hebbian reinforcement failed: w0={w0:.4f} w1={w1:.4f}"

    def test_sleep_decay_reduces_weight(self, embed, hip):
        text = "fact for decay test"
        hip.store(embed.encode(text), text)
        w0 = hip.raw_select("SELECT weight FROM hippocampus WHERE text_meta=?", (text,))[0][0]
        hip.sleep_decay()
        w1 = hip.raw_select("SELECT weight FROM hippocampus WHERE text_meta=?", (text,))[0][0]
        assert w1 < w0

    def test_stats_accurate(self, embed, hip):
        hip.store(embed.encode("biology"), "animal cell",    brain="biology")
        hip.store(embed.encode("code"),    "python script",  brain="technology")
        hip.store(embed.encode("physics"), "kinetic energy", brain="physics")
        s = hip.stats()
        assert s["total"] == 3
        assert s["by_brain"]["biology"]    == 1
        assert s["by_brain"]["technology"] == 1
        assert s["by_brain"]["physics"]    == 1


class TestGlobalWorkspace:

    def test_8_default_brains_created(self, workspace):
        assert len(workspace._brains) == 8

    def test_all_default_domains_present(self, workspace):
        expected = {"technology","biology","physics","mathematics",
                    "medicine","history","geography","linguistics"}
        assert set(workspace._brains.keys()) == expected

    def test_all_brains_share_same_hippocampus(self, workspace):
        hip_ids = {id(b._hip) for b in workspace._brains.values()}
        assert len(hip_ids) == 1

    def test_each_brain_has_unique_domain_sdr(self, workspace):
        sdrs = [tuple(b.domain_sdr._idx) for b in workspace._brains.values()]
        assert len(set(sdrs)) == len(sdrs)

    def test_learn_stores_in_hippocampus(self, workspace, hip):
        result = workspace.learn("photosynthesis converts sunlight into glucose using chlorophyll")
        assert result.stored and result.row_id > 0
        rows = hip.raw_select("SELECT text_meta FROM hippocampus WHERE id=?", (result.row_id,))
        assert len(rows) == 1
        assert "photosynthesis" in rows[0][0]

    def test_learn_dedup_returns_row_id_zero(self, workspace):
        text = "python is an interpreted programming language"
        workspace.learn(text)
        assert workspace.learn(text).row_id == 0

    def test_query_confident_after_learn(self, workspace):
        text = "Pythagoras theorem states that a squared plus b squared equals c squared"
        workspace.learn(text, weight=3.0)
        assert workspace.query(text).confident

    def test_query_not_confident_without_data(self, workspace):
        result = workspace.query("topological superconductors zero temperature")
        assert not result.confident
        assert result.score == 0.0

    def test_domain_relevance_geometric_not_keyword(self, workspace):
        """
        Validates geometric discriminability of domain SDRs.
        Uses medical vs technology texts — these have the most distinct
        token sets even with English stopword filtering.
        """
        embed   = workspace._embed
        sdr_med = embed.encode("virus infection antibody vaccine diagnosis medicine patient")
        sdr_tech= embed.encode("python algorithm compiler database programming software code")

        rel_med_on_med   = workspace._brains["medicine"].domain_relevance(sdr_med)
        rel_tech_on_med  = workspace._brains["technology"].domain_relevance(sdr_med)
        rel_tech_on_tech = workspace._brains["technology"].domain_relevance(sdr_tech)
        rel_med_on_tech  = workspace._brains["medicine"].domain_relevance(sdr_tech)

        # Medicine brain should score higher on medical text than technology
        assert rel_med_on_med > rel_tech_on_med, (
            f"Medicine brain not more relevant for medical text: "
            f"med={rel_med_on_med:.4f} tech={rel_tech_on_med:.4f}"
        )
        # Scores must differ between domains (geometric, not decorative)
        assert rel_med_on_med != rel_tech_on_med
        assert rel_tech_on_tech != rel_med_on_tech

    def test_add_brain_dynamic_shares_hippocampus(self, workspace, hip):
        brain = workspace.add_brain("astronomy", "Astronomy",
                                    "star planet galaxy orbit black hole universe cosmos")
        assert id(brain._hip) == id(hip)

    def test_add_brain_learns_correctly(self, workspace):
        workspace.add_brain("cooking", "Cooking",
                            "recipe ingredient spice dish cook gastronomy chef")
        text = "risotto is an Italian dish made with arborio rice and broth"
        r    = workspace.learn(text, brain_id="cooking")
        assert r.stored and r.row_id > 0
        raw = workspace._brains["cooking"]._hip.raw_select(
            "SELECT text_meta, brain_origin FROM hippocampus WHERE id=?", (r.row_id,)
        )
        assert len(raw) == 1
        assert raw[0][1] == "cooking"
        assert "risotto" in raw[0][0]

    def test_remove_brain(self, workspace):
        workspace.add_brain("temp", "Temp", "temporary")
        assert workspace.remove_brain("temp")
        assert "temp" not in workspace._brains

    def test_sleep_decrements_weights(self, workspace):
        workspace.learn("fact for sleep decay test")
        result = workspace.sleep()
        assert result["sleep_cycle"] == 1
        assert result["decayed_facts"] >= 1

    def test_cross_domain_query(self, workspace):
        workspace.learn("kinetic energy is proportional to mass and velocity squared",
                        brain_id="physics")
        hits = workspace._brains["technology"].query(
            "kinetic energy mass velocity", cross_domain=True
        )
        assert any("kinetic energy" in h.text for h in hits)


class TestEpistemicState:

    def test_system_admits_ignorance(self, nexus):
        response = nexus.chat("what is a quasar?", web_fallback=False)
        assert "insufficient" in response.lower() or "insuficiente" in response.lower()

    def test_system_answers_after_learning(self, nexus):
        text = "a quasar is an extremely luminous active galactic nucleus"
        nexus.learn(text, weight=3.0)
        response = nexus.chat("what is a quasar?", web_fallback=False)
        assert "insufficient" not in response.lower()
        assert "quasar" in response.lower()

    def test_query_result_explicit_confidence_flag(self, nexus):
        before = nexus.workspace.query("topological superconductors zero point")
        assert hasattr(before, "confident") and not before.confident
        nexus.learn("black hole is a region with extreme gravity", weight=3.0)
        after = nexus.workspace.query("black hole is a region with extreme gravity")
        assert after.confident

    def test_learn_returns_explicit_result(self, nexus):
        r = nexus.learn("neuron is the basic unit of the nervous system")
        assert r.stored and r.row_id > 0 and r.brain_id != ""

    def test_dedup_explicit_false(self, nexus):
        text = "DNA is the molecule that carries genetic information"
        nexus.learn(text)
        assert nexus.learn(text).row_id == 0


class TestTextWeaver:

    def test_responds_with_learned_text(self, workspace):
        text = "DNA contains genetic information encoded in nucleotides"
        workspace.learn(text, weight=3.0)
        weaver = TextWeaver(workspace, web_brain=None)
        resp   = weaver.respond("what is DNA?", web_fallback=False)
        assert "dna" in resp.lower() or "DNA" in resp

    def test_returns_insufficient_when_empty(self, workspace):
        weaver = TextWeaver(workspace, web_brain=None)
        resp   = weaver.respond("antimatter wormhole", web_fallback=False)
        assert "insufficient" in resp.lower()

    def test_learn_and_respond_confirms_storage(self, workspace):
        weaver = TextWeaver(workspace, web_brain=None)
        resp   = weaver.learn_and_respond("entropy is the measure of disorder")
        assert "Learned" in resp


class TestVecOps:

    def test_dot_product(self):
        assert VecOps.dot([1,2,3],[4,5,6]) == pytest.approx(32.0)

    def test_norm(self):
        assert VecOps.norm([3,4]) == pytest.approx(5.0)

    def test_cosine_identical(self):
        v = [1.0, 2.0, 3.0]
        assert VecOps.cosine(v, v) == pytest.approx(1.0)

    def test_cosine_orthogonal(self):
        assert VecOps.cosine([1,0],[0,1]) == pytest.approx(0.0)

    def test_sdr_to_dense_correct_positions(self):
        sdr   = SparseSDR([0, 5, 100])
        dense = VecOps.sdr_to_dense(sdr)
        if HAS_NUMPY:
            assert dense[0] == 1.0 and dense[5] == 1.0 and dense[1] == 0.0
        else:
            assert dense[0] == 1.0 and dense[5] == 1.0


class TestHippocampusAsync:

    def test_async_store_and_recall(self, embed):
        async def _run():
            import tempfile, os
            tmp  = tempfile.mktemp(suffix=".db")
            hipa = HippocampusAsync(db_path=tmp)
            try:
                sdr = embed.encode("astronomy studies stars and galaxies")
                rid = await hipa.store(sdr, "astronomy studies stars and galaxies",
                                       brain="astronomy")
                assert rid > 0
                hits = await hipa.recall(embed.encode("astronomy stars galaxies"), top_k=3)
                assert len(hits) > 0
                assert any("astronomy" in h[1] for h in hits)
            finally:
                hipa.close()
                try: os.unlink(tmp)
                except: pass
        asyncio.run(_run())

    def test_async_knows_false_when_empty(self, embed):
        async def _run():
            import tempfile, os
            tmp  = tempfile.mktemp(suffix=".db")
            hipa = HippocampusAsync(db_path=tmp)
            try:
                knows = await hipa.knows(embed.encode("completely unknown xyzzy content"))
                assert not knows
            finally:
                hipa.close()
                try: os.unlink(tmp)
                except: pass
        asyncio.run(_run())


class TestFastAPIE2E:
    """
    End-to-End test: spins up the server in memory via TestClient,
    sends JSON payloads and validates the full cognitive response.
    """

    @pytest.fixture(autouse=False)
    def client(self):
        """Each test gets an isolated server with its own temporary database."""
        import os, tempfile
        tmp = tempfile.mktemp(suffix=".db")
        os.environ["NEXUS_DB_PATH"] = tmp
        from fastapi.testclient import TestClient
        from nexus.api.server import app
        with TestClient(app) as c:
            yield c
        os.environ.pop("NEXUS_DB_PATH", None)
        try: os.unlink(tmp)
        except: pass

    def test_health_endpoint_online(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "online" and data["ready"] is True

    def test_brains_endpoint_8_brains(self, client):
        data = client.get("/brains").json()
        assert data["count"] == 8

    def test_learn_stores_and_confirms(self, client):
        resp = client.post("/learn", json={
            "text": "chlorophyll is the pigment that captures light in plants",
            "brain_id": "biology", "weight": 2.0,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["stored"] is True and data["row_id"] > 0
        assert data["brain_id"] == "biology"

    def test_chat_confident_after_learn(self, client):
        client.post("/learn", json={
            "text":   "mitosis is cell division that generates genetically identical cells",
            "weight": 3.0,
        })
        resp = client.post("/chat", json={
            "message":     "mitosis is cell division that generates genetically identical cells",
            "web_fallback": False,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["confident"] is True
        assert "insufficient" not in data["response"].lower()
        assert "latency_ms" in data and "sdr_sig63" in data

    def test_chat_not_confident_without_data(self, client):
        resp = client.post("/chat", json={
            "message":     "xyzzy_foobar_quux_nevermatch_zzz_unknown_9999",
            "web_fallback": False,
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["confident"] is False

    def test_search_returns_stored_fact(self, client):
        client.post("/learn", json={"text": "heapsort uses a heap structure to sort elements"})
        resp  = client.post("/search", json={"query": "heapsort heap sort", "top_k": 5})
        assert resp.status_code == 200
        texts = [h["text"] for h in resp.json()["hits"]]
        assert any("heapsort" in t for t in texts)

    def test_learn_dedup_returns_stored_false(self, client):
        text = "Ohm's law states that V equals I times R"
        client.post("/learn", json={"text": text})
        data = client.post("/learn", json={"text": text}).json()
        assert data["stored"] is False and data["row_id"] == 0

    def test_sleep_endpoint(self, client):
        client.post("/learn", json={"text": "fact for sleep test"})
        data = client.post("/sleep").json()
        assert data["sleep_cycle"] == 1 and "decayed_facts" in data

    def test_full_e2e_pipeline(self, client):
        """Full pipeline: learn -> search -> chat -> sleep -> health."""
        r1 = client.post("/learn", json={
            "text":   "neuron transmits electrical impulses via synapses",
            "weight": 2.5,
        }).json()
        assert r1["stored"] and r1["row_id"] > 0

        r2 = client.post("/search", json={
            "query": "neuron electrical impulse synapse", "top_k": 3,
        }).json()
        assert len(r2["hits"]) > 0 and r2["hits"][0]["score"] > 0

        r3 = client.post("/chat", json={
            "message":     "neuron transmits electrical impulses via synapses",
            "web_fallback": False,
        }).json()
        assert r3["confident"]
        assert "neuron" in r3["response"].lower()

        r4 = client.post("/sleep").json()
        assert r4["decayed_facts"] >= 1

        r5 = client.get("/health").json()
        assert r5["system"]["hippocampus"]["total"] >= 1
