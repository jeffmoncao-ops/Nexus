"""
Nexus V2 — Kernel Cognitivo SDR
================================
Sistema cognitivo baseado em Sparse Distributed Representations.

Uso rápido:
    from nexus import Nexus
    nx = Nexus()
    nx.learn("fotossíntese converte luz solar em glicose")
    response = nx.chat("o que é fotossíntese?")
    print(response)        # resposta com confiança, ou "Dados insuficientes"
"""
from nexus.core.sdr_math import SparseSDR, MiniEmbed, XORBinding, VecOps
from nexus.memory.hippocampus import Hippocampus, CONFIDENCE_THRESHOLD
from nexus.cognitive.brains import GlobalWorkspace, QueryResult
from nexus.cognitive.text_weaver import TextWeaver, WebBrain


class Nexus:
    """
    Interface principal do sistema.

    Métodos:
      learn(text)            → LearnResult
      chat(text)             → str (com estado epistêmico)
      search(text, top_k)    → List[QueryResult]
      add_brain(id, name, domain_text) → SpecialistBrain
      sleep()                → dict
      health()               → dict
    """

    def __init__(
        self,
        db_path:     str  = ":memory:",
        web_enabled: bool = False,
    ):
        self._embed     = MiniEmbed()
        self._hip       = Hippocampus(db_path=db_path)
        self._workspace = GlobalWorkspace(self._hip, self._embed)
        self._web       = WebBrain(self._workspace) if web_enabled else None
        self._weaver    = TextWeaver(self._workspace, self._web)

    def learn(self, text: str, brain_id=None, weight: float = 1.0):
        return self._workspace.learn(text.strip(), brain_id=brain_id,
                                      weight=weight)

    def chat(self, text: str, web_fallback: bool = True) -> str:
        return self._weaver.respond(text.strip(), web_fallback=web_fallback)

    def search(self, text: str, top_k: int = 5):
        sdr = self._embed.encode(text)
        return self._hip.recall(sdr, top_k=top_k)

    def add_brain(self, brain_id: str, name: str, domain_text: str):
        return self._workspace.add_brain(brain_id, name, domain_text)

    def sleep(self) -> dict:
        return self._workspace.sleep()

    def health(self) -> dict:
        return self._workspace.health()

    @property
    def workspace(self) -> GlobalWorkspace:
        return self._workspace

    @property
    def hippocampus(self) -> Hippocampus:
        return self._hip
