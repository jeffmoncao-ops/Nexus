from nexus.cognitive.brains import (
    GlobalWorkspace, SpecialistBrain,
    QueryResult, LearnResult, DEFAULT_DOMAINS,
)
from nexus.cognitive.text_weaver import TextWeaver, WebBrain

__all__ = [
    "GlobalWorkspace", "SpecialistBrain",
    "QueryResult", "LearnResult", "DEFAULT_DOMAINS",
    "TextWeaver", "WebBrain",
]
