"""
nexus/cognitive/brains.py
=========================
Cérebros especialistas com assinatura SDR geométrica.

Diferença fundamental do v1:
  - NÃO usa keyword matching (if "python" in text)
  - Cada brain possui um DOMAIN SDR — vetor de identidade geométrico
  - Ao fazer query, aplica XOR do domain SDR com a pergunta:
      query_filtered = query_sdr XOR domain_sdr  (k-WTA)
    Isso "torce" o espaço de busca na direção do domínio.
  - Resulta em perspectivas cognitivas reais, não roteamento de texto.

Estado epistêmico rigoroso:
  - knows()    → True apenas se Jaccard ≥ CONFIDENCE_THRESHOLD
  - query()    → retorna hits com score explícito
  - "não sei"  → sinalizado por QueryResult.confident = False
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from nexus.core.sdr_math import MiniEmbed, SparseSDR, XORBinding, SDR_ACTIVE, SDR_SIZE
from nexus.memory.hippocampus import (
    Hippocampus, CONFIDENCE_THRESHOLD, RECALL_THRESHOLD
)


# ══════════════════════════════════════════════════════════════════════════════
# QueryResult — resposta com estado epistêmico explícito
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class QueryResult:
    """
    Resultado de uma consulta ao sistema.
    confident = False é o gatilho explícito para o WebBrain agir.
    """
    text:       str
    score:      float
    brain_id:   str
    confident:  bool        # True apenas se score ≥ CONFIDENCE_THRESHOLD
    cross_domain: bool = False

    def __bool__(self) -> bool:
        return self.confident


@dataclass
class LearnResult:
    """Resultado de um aprendizado."""
    stored:     bool
    text:       str
    brain_id:   str
    row_id:     int    # 0 = duplicata


# ══════════════════════════════════════════════════════════════════════════════
# SpecialistBrain — cérebro especialista com domain SDR
# ══════════════════════════════════════════════════════════════════════════════

class SpecialistBrain:
    """
    Cérebro especialista identificado por seu DOMAIN SDR.

    O domain_sdr é gerado a partir do texto de definição do domínio.
    Ao consultar o hipocampo, o brain aplica XOR domain+query para
    filtrar geometricamente no espaço de 4096 dimensões.
    """

    def __init__(
        self,
        brain_id:    str,
        name:        str,
        domain_text: str,          # texto que define o domínio (vira SDR)
        embed:       MiniEmbed,
        hippocampus: Hippocampus,
    ):
        self.id          = brain_id
        self.name        = name
        self._embed      = embed
        self._hip        = hippocampus
        self._xor        = XORBinding(embed)

        # Domain SDR — assinatura geométrica do domínio
        # Usa múltiplas codificações dos termos do domínio para maior
        # discriminabilidade no espaço de 4096 dimensões (240 bits ativos).
        self.domain_sdr  = self._build_domain_sdr(embed, domain_text)

        # Estatísticas
        self._learned    = 0
        self._queried    = 0
        self._confident  = 0

    @staticmethod
    def _build_domain_sdr(embed: MiniEmbed, domain_text: str) -> SparseSDR:
        """
        Constrói um domain SDR rico a partir dos tokens do texto de domínio.
        Cada token é codificado individualmente; os bits são acumulados e
        passados por k-WTA → 3×SDR_ACTIVE bits = assinatura mais discriminativa.
        """
        import re as _re
        tokens = list(set(__import__('re').findall(r'\w{3,}', domain_text.lower())))[:20]
        all_bits: set = set()
        for tok in tokens:
            sdr = embed.encode(tok)
            all_bits.update(sdr._idx)
        lst  = sorted(all_bits)
        n    = SDR_ACTIVE * 6  # 360 bits → assinatura rica no espaço 8192
        step = max(1, len(lst) // n)
        return SparseSDR(lst[::step][:n])

    def _domain_filter(self, query_sdr: SparseSDR) -> SparseSDR:
        """
        Aplica XOR com domain SDR e k-WTA.
        "Torce" o vetor de query na direção do domínio.
        """
        raw = set(query_sdr._idx) ^ set(self.domain_sdr._idx)
        if len(raw) > SDR_ACTIVE:
            lst  = sorted(raw)
            step = max(1, len(lst) // SDR_ACTIVE)
            raw  = set(lst[::step][:SDR_ACTIVE])
        return SparseSDR(raw)

    def domain_relevance(self, query_sdr: SparseSDR) -> float:
        """
        Jaccard entre query e domain_sdr.
        Score geométrico — não depende de palavras-chave.
        """
        return query_sdr.jaccard(self.domain_sdr)

    def learn(self, text: str, weight: float = 1.0) -> LearnResult:
        """Aprende um fato — armazena no hipocampo compartilhado."""
        sdr = self._embed.encode(text)
        rid = self._hip.store(sdr, text, brain=self.id, weight=weight)
        if rid > 0:
            self._learned += 1
        return LearnResult(
            stored=rid > 0, text=text, brain_id=self.id, row_id=rid
        )

    def query(self, text: str, top_k: int = 3,
              cross_domain: bool = False) -> List[QueryResult]:
        """
        Consulta com filtro geométrico de domínio.
        cross_domain=True: busca em todo o hipocampo com query SDR original
                           (sem domain filter — maximiza recall inter-domínio).
        cross_domain=False: aplica domain filter para busca especializada.
        """
        self._queried += 1
        query_sdr = self._embed.encode(text)

        if cross_domain:
            # Cross-domain: usa SDR original para máximo recall
            search_sdr   = query_sdr
            brain_filter = None
        else:
            # Intra-domain: aplica filtro geométrico de domínio
            search_sdr   = self._domain_filter(query_sdr)
            brain_filter = self.id

        hits = self._hip.recall(
            search_sdr,
            top_k=top_k,
            brain_filter=brain_filter,
            min_jaccard=RECALL_THRESHOLD,
            cross_domain=cross_domain,
        )

        results = []
        for score, text_hit, brain_hit in hits:
            confident = score >= CONFIDENCE_THRESHOLD
            if confident:
                self._confident += 1
            results.append(QueryResult(
                text=text_hit,
                score=score,
                brain_id=brain_hit,
                confident=confident,
                cross_domain=cross_domain,
            ))
        return results

    def knows(self, text: str) -> bool:
        q = self._embed.encode(text)
        f = self._domain_filter(q)
        return self._hip.knows(f)

    @property
    def stats(self) -> dict:
        facts = len(self._hip.all_facts(brain_filter=self.id))
        return {
            "id":        self.id,
            "name":      self.name,
            "facts":     facts,
            "learned":   self._learned,
            "queried":   self._queried,
            "confident": self._confident,
        }


# ══════════════════════════════════════════════════════════════════════════════
# GlobalWorkspace — orquestrador multi-brain
# ══════════════════════════════════════════════════════════════════════════════

# Domínios padrão — definidos por texto semântico rico, não por keywords
DEFAULT_DOMAINS: List[Dict] = [
    {
        "id":   "tecnologia",
        "name": "Tecnologia e Computação",
        "text": ("programação código software algoritmo computador sistema "
                 "python javascript banco dados rede internet api servidor "
                 "inteligência artificial machine learning compilador memória"),
    },
    {
        "id":   "biologia",
        "name": "Biologia e Ciências da Vida",
        "text": ("célula dna rna proteína evolução organismo fotossíntese "
                 "mitose meiose genética cromossomo metabolismo enzima "
                 "vírus bactéria ecossistema biodiversidade genoma"),
    },
    {
        "id":   "fisica",
        "name": "Física",
        "text": ("átomo partícula elétron força energia gravidade velocidade "
                 "massa onda frequência calor temperatura termodinâmica "
                 "eletricidade magnetismo relatividade quantum fóton"),
    },
    {
        "id":   "matematica",
        "name": "Matemática",
        "text": ("número função equação integral derivada logaritmo "
                 "probabilidade estatística geometria álgebra cálculo "
                 "teorema número primo matrix vetor limite série"),
    },
    {
        "id":   "medicina",
        "name": "Medicina e Saúde",
        "text": ("doença sintoma diagnóstico tratamento medicamento vacina "
                 "infecção imunidade anticorpo órgão coração pulmão "
                 "câncer diabetes cirurgia nutrição hormônio epidemia"),
    },
    {
        "id":   "historia",
        "name": "História",
        "text": ("guerra revolução império civilização descoberta colônia "
                 "política governo presidente século democracia ditadura "
                 "colonialismo independência tratado renascimento"),
    },
    {
        "id":   "geografia",
        "name": "Geografia",
        "text": ("brasil amazônia continente país capital cidade oceano "
                 "montanha clima bioma floresta cerrado território "
                 "população migração urbanização região"),
    },
    {
        "id":   "linguistica",
        "name": "Linguística e Literatura",
        "text": ("língua gramática sintaxe semântica fonologia morfologia "
                 "texto discurso comunicação português literatura poema "
                 "metáfora analogia linguagem escrita autor"),
    },
]


class GlobalWorkspace:
    """
    Orquestrador multi-brain com hipocampo compartilhado.

    Fluxo de processamento:
      1. learn(text) → embed → store no hipocampo → propaga para brains relevantes
      2. query(text) → embed → estado epistêmico:
           a. knows() True  → retorna melhor hit com brain de origem
           b. knows() False → retorna QueryResult(confident=False)
                              gatilho explícito para WebBrain
      3. Brains consultados em paralelo via domain_relevance geométrico
      4. sleep() → decaimento Hebbiano no hipocampo
    """

    def __init__(
        self,
        hippocampus:   Hippocampus,
        embed:         MiniEmbed,
        domains:       Optional[List[Dict]] = None,
    ):
        self._hip    = hippocampus
        self._embed  = embed
        self._xor    = XORBinding(embed)
        self._brains: Dict[str, SpecialistBrain] = {}
        self._stats  = {
            "learned":          0,
            "queries":          0,
            "confident_hits":   0,
            "uncertain_hits":   0,
            "propagations":     0,
            "sleep_cycles":     0,
        }

        dom_list = domains if domains is not None else DEFAULT_DOMAINS
        for d in dom_list:
            self._brains[d["id"]] = SpecialistBrain(
                brain_id    = d["id"],
                name        = d["name"],
                domain_text = d["text"],
                embed       = embed,
                hippocampus = hippocampus,
            )

    # ── API pública ────────────────────────────────────────────────────────────

    def learn(self, text: str, brain_id: Optional[str] = None,
              weight: float = 1.0) -> LearnResult:
        """
        Aprende um fato.
        Se brain_id não especificado, propaga para o brain geometricamente mais próximo.
        """
        sdr    = self._embed.encode(text)
        target = brain_id or self._best_brain(sdr)

        if target and target in self._brains:
            result = self._brains[target].learn(text, weight)
        else:
            # Fallback: armazena no hipocampo sem brain específico
            rid = self._hip.store(sdr, text, brain="core", weight=weight)
            result = LearnResult(stored=rid > 0, text=text,
                                  brain_id="core", row_id=rid)

        if result.stored:
            self._stats["learned"] += 1
            if target and target != brain_id:
                self._stats["propagations"] += 1

        return result

    def query(self, text: str, top_k: int = 3,
              cross_domain: bool = True) -> QueryResult:
        """
        Consulta o sistema com estado epistêmico explícito.

        Retorna:
          - QueryResult(confident=True)  se Jaccard ≥ CONFIDENCE_THRESHOLD
          - QueryResult(confident=False) se nada suficientemente similar
            → este é o gatilho para o WebBrain
        """
        self._stats["queries"] += 1
        query_sdr = self._embed.encode(text)

        # Busca direta no hipocampo (cross-domain)
        hits = self._hip.recall(
            query_sdr, top_k=top_k, min_jaccard=RECALL_THRESHOLD,
            cross_domain=cross_domain
        )

        if hits:
            score, text_hit, brain_hit = hits[0]
            confident = score >= CONFIDENCE_THRESHOLD
            if confident:
                self._stats["confident_hits"] += 1
            else:
                self._stats["uncertain_hits"] += 1
            return QueryResult(
                text=text_hit, score=score,
                brain_id=brain_hit, confident=confident,
                cross_domain=cross_domain,
            )

        self._stats["uncertain_hits"] += 1
        return QueryResult(
            text="", score=0.0,
            brain_id="", confident=False,
        )

    def query_multi(self, text: str,
                    top_k: int = 3) -> List[QueryResult]:
        """Consulta todos os brains e retorna resultados ordenados por score."""
        self._stats["queries"] += 1
        query_sdr = self._embed.encode(text)
        results   = []

        for brain in self._brains.values():
            rel = brain.domain_relevance(query_sdr)
            if rel < 0.02:   # ignora domínios irrelevantes geometricamente
                continue
            hits = brain.query(text, top_k=top_k, cross_domain=False)
            results.extend(hits)

        results.sort(key=lambda r: -r.score)
        return results[:top_k]

    def add_brain(self, brain_id: str, name: str,
                  domain_text: str) -> SpecialistBrain:
        """Adiciona brain customizado — herda mesmo hipocampo."""
        brain = SpecialistBrain(
            brain_id=brain_id, name=name,
            domain_text=domain_text,
            embed=self._embed,
            hippocampus=self._hip,
        )
        self._brains[brain_id] = brain
        return brain

    def remove_brain(self, brain_id: str) -> bool:
        if brain_id in self._brains:
            del self._brains[brain_id]
            return True
        return False

    def sleep(self) -> dict:
        """Decaimento Hebbiano e consolidação."""
        self._stats["sleep_cycles"] += 1
        affected = self._hip.sleep_decay()
        return {"sleep_cycle": self._stats["sleep_cycles"],
                "decayed_facts": affected}

    # ── Diagnóstico ────────────────────────────────────────────────────────────

    def brain_status(self) -> str:
        lines = ["Brains ativos:"]
        for b in self._brains.values():
            s = b.stats
            lines.append(
                f"  [{s['id']:12s}] {s['name']:30s} "
                f"fatos={s['facts']:4d}  "
                f"aprendidos={s['learned']:4d}  "
                f"confiantes={s['confident']:4d}"
            )
        return "\n".join(lines)

    def health(self) -> dict:
        return {
            "hippocampus": self._hip.stats(),
            "brains":      {bid: b.stats for bid, b in self._brains.items()},
            "stats":       self._stats,
        }

    # ── Internos ───────────────────────────────────────────────────────────────

    def _best_brain(self, sdr: SparseSDR) -> Optional[str]:
        """Retorna o brain com maior domain_relevance geométrico."""
        best_id, best_score = None, 0.0
        for bid, brain in self._brains.items():
            rel = brain.domain_relevance(sdr)
            if rel > best_score:
                best_score, best_id = rel, bid
        return best_id if best_score > 0.02 else None
