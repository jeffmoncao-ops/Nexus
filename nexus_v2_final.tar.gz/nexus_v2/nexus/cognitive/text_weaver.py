"""
nexus/cognitive/text_weaver.py
==============================
TextWeaver — formatação de saída baseada em estado epistêmico.

NÃO gera texto estatisticamente. NÃO usa n-gramas.

Princípio: o sistema só diz o que sabe.
  - Se confident=True  → formata a memória recuperada
  - Se confident=False → retorna "Dados insuficientes"
                         (gatilho para WebBrain)
  - Após aprender via WebBrain → reformata com o novo conhecimento

O WebBrain é integrado aqui como componente opcional (pode ser None
em ambientes sem rede).
"""
from __future__ import annotations

import re
from typing import Optional

from nexus.cognitive.brains import GlobalWorkspace, QueryResult


# Respostas de "não sei" — determinísticas, não aleatórias
_INSUFFICIENT = "Dados insuficientes na memória local."
_LEARNED      = "Aprendi: \"{text}\""
_DUPLICATE    = "[dedup] Já conheço algo similar: \"{text}\""
_BLOCKED      = "🛡️ Entrada bloqueada: {reason}"


class TextWeaver:
    """
    Formata respostas baseadas em QueryResult.
    Integra WebBrain opcionalmente.
    """

    def __init__(
        self,
        workspace:  GlobalWorkspace,
        web_brain:  Optional["WebBrain"] = None,     # injetado pela API
    ):
        self._ws  = workspace
        self._web = web_brain

    def respond(self, query: str,
                web_fallback: bool = True) -> str:
        """
        Processa uma query e retorna resposta em texto.

        Fluxo:
          1. query_sdr → hipocampo
          2. confident=True  → formata hit
          3. confident=False → se web_brain disponível, busca e aprende
                             → reformula ou retorna "Dados insuficientes"
        """
        result = self._ws.query(query)

        if result.confident:
            return self._format_hit(result)

        # Não sabe — tenta WebBrain
        if web_fallback and self._web is not None:
            learned_text = self._web.fetch_and_learn(query)
            if learned_text:
                # Retenta com o novo conhecimento
                result2 = self._ws.query(query)
                if result2.confident:
                    return f"🌐 [Web] {self._format_hit(result2)}"
                # Aprendeu mas ainda não confiante — retorna o que aprendeu
                return f"🌐 [Web] Aprendi recentemente: {learned_text[:300]}"

        return _INSUFFICIENT

    def learn_and_respond(self, text: str) -> str:
        """Aprende um fato e retorna confirmação."""
        result = self._ws.learn(text)
        if result.row_id == 0:
            best = self._ws.query(text)
            return _DUPLICATE.format(text=best.text[:60] if best.text else text[:60])
        return _LEARNED.format(text=text[:80])

    def _format_hit(self, result: QueryResult) -> str:
        """Formata o texto recuperado — sem invenção, só o que está na memória."""
        text = result.text.strip()
        if not text:
            return _INSUFFICIENT
        # Garante que é uma frase completa (termina com pontuação)
        if text and text[-1] not in ".!?":
            text += "."
        origin = f" [{result.brain_id}]" if result.brain_id else ""
        return f"{text}{origin}"


# ══════════════════════════════════════════════════════════════════════════════
# WebBrain — busca assíncrona / síncrona via Wikipedia
# ══════════════════════════════════════════════════════════════════════════════

class WebBrain:
    """
    Busca informações externas e alimenta o GlobalWorkspace.
    Ativado APENAS quando o sistema não tem resposta confiante.
    """

    def __init__(self, workspace: GlobalWorkspace, timeout: float = 4.0):
        self._ws      = workspace
        self._timeout = timeout
        self.active   = True

    def fetch_and_learn(self, query: str) -> Optional[str]:
        """
        Busca na Wikipedia PT e aprende no hipocampo.
        Retorna texto aprendido ou None se falhou.
        Versão síncrona — usa urllib sem dependências extras.
        """
        if not self.active:
            return None

        # Extrai o tópico mais longo da query
        words = sorted(re.findall(r'\w{4,}', query.lower()),
                       key=len, reverse=True)
        if not words:
            return None
        topic = words[0]

        try:
            import urllib.request, json, urllib.parse
            encoded = urllib.parse.quote(topic)
            url     = (f"https://pt.wikipedia.org/api/rest_v1"
                       f"/page/summary/{encoded}")
            req     = urllib.request.Request(
                url, headers={"User-Agent": "NexusV2/1.0"}
            )
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                data    = json.loads(resp.read().decode())
                extract = data.get("extract", "").strip()
                if extract and len(extract) > 30:
                    # Aprende com peso maior (fonte externa verificada)
                    self._ws.learn(extract, weight=2.0)
                    return extract
        except Exception:
            pass
        return None
