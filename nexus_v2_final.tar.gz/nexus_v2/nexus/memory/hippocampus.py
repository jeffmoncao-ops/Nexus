"""
nexus/memory/hippocampus.py
===========================
Hipocampo Unificado — única fonte de verdade do sistema.

Arquitetura L1/L2:
  L1 — filtro 63-bit AND bitwise em SQL  → O(1) com índice
  L2 — Jaccard exato 4096-bit em Python  → refinamento semântico

Sem FTS5. Sem texto como índice primário.
O texto é metadado anexado ao BLOB do SDR.

Schema:
  id            : PK autoincrement
  sdr_63bit     : INTEGER  — assinatura L1 (63 bits)
  sdr_blob      : BLOB     — SDR completo 4096-bit serializado
  text_meta     : TEXT     — texto original (metadado, não índice)
  brain_origin  : TEXT     — qual brain armazenou
  temporal_block: INTEGER  — bucket temporal (hora Unix // 3600)
  weight        : REAL     — peso Hebbiano [0.01 .. 5.0]
  access_count  : INTEGER  — quantas vezes foi recuperado
  ts            : REAL     — timestamp Unix
"""
from __future__ import annotations

import asyncio
import math
import sqlite3
import time
from typing import List, Optional, Tuple

from nexus.core.sdr_math import SparseSDR


# Constantes Hebbianas
RECALL_BOOST = 0.15
DECAY_RATE   = 0.998
DECAY_FLOOR  = 0.01
INIT_WEIGHT  = 1.0

# Threshold de confiança mínima para "saber algo"
CONFIDENCE_THRESHOLD = 0.25   # Jaccard mínimo para confiança (ajustado para 8192/60bits)
RECALL_THRESHOLD     = 0.05   # Jaccard mínimo para recall (sparser SDR → threshold menor)


class Hippocampus:
    """
    Hipocampo síncrono (sqlite3 com check_same_thread=False).
    Usa conexão persistente — sem o problema de múltiplos :memory: por connect().

    Para uso assíncrono no FastAPI, use HippocampusAsync.
    """

    def __init__(self, db_path: str = ":memory:"):
        self.db_path  = db_path
        self._conn    = sqlite3.connect(db_path, check_same_thread=False)
        self._lock    = asyncio.Lock()
        self._setup()

    def _setup(self) -> None:
        self._conn.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=NORMAL;

            CREATE TABLE IF NOT EXISTS hippocampus (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                sdr_63bit       INTEGER NOT NULL,
                sdr_blob        BLOB    NOT NULL,
                text_meta       TEXT    NOT NULL DEFAULT '',
                brain_origin    TEXT    NOT NULL DEFAULT 'core',
                temporal_block  INTEGER NOT NULL,
                weight          REAL    NOT NULL DEFAULT 1.0,
                access_count    INTEGER NOT NULL DEFAULT 0,
                ts              REAL    NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_l1
                ON hippocampus(sdr_63bit);

            CREATE INDEX IF NOT EXISTS idx_weight
                ON hippocampus(weight DESC);

            CREATE INDEX IF NOT EXISTS idx_brain
                ON hippocampus(brain_origin);

            CREATE INDEX IF NOT EXISTS idx_temporal
                ON hippocampus(temporal_block DESC);
        """)
        self._conn.commit()

    # ── Escrita ────────────────────────────────────────────────────────────────

    def store(self, sdr: SparseSDR, text: str,
              brain: str = "core", weight: float = INIT_WEIGHT) -> int:
        """
        Armazena SDR + metadado texto.
        Retorna o id inserido (> 0) ou 0 se já existia entry idêntica.
        """
        sig63  = sdr.to_hex_signature()
        blob   = sdr.to_blob()
        tblock = int(time.time() / 3600)
        ts     = time.time()

        # Verifica duplicata exata (mesmo texto)
        existing = self._conn.execute(
            "SELECT id FROM hippocampus WHERE text_meta = ? LIMIT 1",
            (text,)
        ).fetchone()
        if existing:
            return 0  # duplicata — não insere

        cur = self._conn.execute(
            "INSERT INTO hippocampus "
            "(sdr_63bit, sdr_blob, text_meta, brain_origin, "
            " temporal_block, weight, access_count, ts) "
            "VALUES (?, ?, ?, ?, ?, ?, 0, ?)",
            (sig63, blob, text, brain, tblock, weight, ts)
        )
        self._conn.commit()
        return cur.lastrowid

    # ── Leitura L1 + L2 ───────────────────────────────────────────────────────

    def recall(self, query_sdr: SparseSDR,
               top_k: int = 5,
               brain_filter: Optional[str] = None,
               min_jaccard: float = RECALL_THRESHOLD,
               cross_domain: bool = True) -> List[Tuple[float, str, str]]:
        """
        Recupera memórias relevantes.

        Retorna lista de (jaccard_score, text_meta, brain_origin)
        ordenada por score decrescente.

        L1: AND bitwise no SQL filtra candidatos (O(1) via índice).
        L2: Jaccard exato 4096-bit em Python refina.

        Se cross_domain=False e brain_filter definido, restringe ao brain.
        """
        sig63 = query_sdr.to_hex_signature()
        if sig63 == 0:
            return []

        current_block = int(time.time() / 3600)

        # L1 — filtro SQL bitwise
        if brain_filter and not cross_domain:
            rows = self._conn.execute("""
                SELECT id, sdr_blob, text_meta, brain_origin, weight, temporal_block
                FROM hippocampus
                WHERE (sdr_63bit & ?) > 0
                  AND brain_origin = ?
                ORDER BY weight * (1.0 / (1.0 + (? - temporal_block))) DESC
                LIMIT 100
            """, (sig63, brain_filter, current_block)).fetchall()
        else:
            rows = self._conn.execute("""
                SELECT id, sdr_blob, text_meta, brain_origin, weight, temporal_block
                FROM hippocampus
                WHERE (sdr_63bit & ?) > 0
                ORDER BY weight * (1.0 / (1.0 + (? - temporal_block))) DESC
                LIMIT 100
            """, (sig63, current_block)).fetchall()

        if not rows:
            return []

        # L2 — refinamento Jaccard 4096-bit
        results: List[Tuple[float, str, str]] = []
        for row_id, blob, text, brain, weight, _ in rows:
            if not blob:
                continue
            mem_sdr = SparseSDR.from_blob(blob)
            j = query_sdr.jaccard(mem_sdr)
            if j < min_jaccard:
                continue
            # Score = Jaccard ponderado pelo peso Hebbiano
            score = j * weight
            results.append((score, text, brain))

        results.sort(key=lambda x: -x[0])
        top = results[:top_k]

        # Reforço Hebbiano nos recuperados
        for _, text, _ in top:
            self._conn.execute("""
                UPDATE hippocampus
                SET weight       = MIN(5.0, weight + ?),
                    access_count = access_count + 1
                WHERE text_meta = ?
            """, (RECALL_BOOST, text))
        if top:
            self._conn.commit()

        return top

    def best_match(self, query_sdr: SparseSDR,
                   brain_filter: Optional[str] = None,
                   cross_domain: bool = True) -> Optional[Tuple[float, str, str]]:
        """Retorna o melhor match ou None."""
        hits = self.recall(query_sdr, top_k=1,
                           brain_filter=brain_filter,
                           cross_domain=cross_domain)
        return hits[0] if hits else None

    def knows(self, query_sdr: SparseSDR,
              threshold: float = CONFIDENCE_THRESHOLD) -> bool:
        """True se o sistema tem memória suficientemente similar."""
        hit = self.best_match(query_sdr)
        return hit is not None and hit[0] >= threshold

    # ── Sono Hebbiano ──────────────────────────────────────────────────────────

    def sleep_decay(self) -> int:
        """Aplica decaimento Hebbiano. Retorna número de fatos afetados."""
        cur = self._conn.execute("""
            UPDATE hippocampus
            SET weight = MAX(?, weight * ?)
            WHERE weight > ?
        """, (DECAY_FLOOR, DECAY_RATE, DECAY_FLOOR))
        self._conn.commit()
        return cur.rowcount

    # ── Estatísticas / Diagnóstico ─────────────────────────────────────────────

    def stats(self) -> dict:
        total = self._conn.execute(
            "SELECT COUNT(*) FROM hippocampus"
        ).fetchone()[0]
        by_brain = dict(self._conn.execute(
            "SELECT brain_origin, COUNT(*) FROM hippocampus GROUP BY brain_origin"
        ).fetchall())
        avg_w = self._conn.execute(
            "SELECT AVG(weight) FROM hippocampus"
        ).fetchone()[0] or 0.0
        return {
            "total":    total,
            "by_brain": by_brain,
            "avg_weight": round(avg_w, 4),
        }

    def all_facts(self, brain_filter: Optional[str] = None) -> List[str]:
        if brain_filter:
            rows = self._conn.execute(
                "SELECT text_meta FROM hippocampus "
                "WHERE brain_origin = ? ORDER BY ts DESC",
                (brain_filter,)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT text_meta FROM hippocampus ORDER BY ts DESC"
            ).fetchall()
        return [r[0] for r in rows]

    # ── SELECT direto (para testes) ────────────────────────────────────────────

    def raw_select(self, sql: str, params: tuple = ()) -> list:
        """SELECT direto ao banco — usado em testes de estado."""
        return self._conn.execute(sql, params).fetchall()

    def close(self) -> None:
        self._conn.close()


# ── Versão assíncrona para FastAPI ─────────────────────────────────────────────

class HippocampusAsync:
    """
    Wrapper assíncrono do Hippocampus síncrono.
    Usa asyncio.Lock para segurança em ambiente async.
    Não usa aiosqlite (evita o bug de múltiplas conexões :memory:).
    """

    def __init__(self, db_path: str = "nexus_hippocampus.db"):
        self._hip  = Hippocampus(db_path=db_path)
        self._lock = asyncio.Lock()

    async def store(self, sdr: SparseSDR, text: str,
                    brain: str = "core", weight: float = INIT_WEIGHT) -> int:
        async with self._lock:
            return self._hip.store(sdr, text, brain, weight)

    async def recall(self, query_sdr: SparseSDR,
                     top_k: int = 5,
                     brain_filter: Optional[str] = None,
                     min_jaccard: float = RECALL_THRESHOLD,
                     cross_domain: bool = True) -> List[Tuple[float, str, str]]:
        async with self._lock:
            return self._hip.recall(query_sdr, top_k, brain_filter,
                                    min_jaccard, cross_domain)

    async def knows(self, query_sdr: SparseSDR,
                    threshold: float = CONFIDENCE_THRESHOLD) -> bool:
        async with self._lock:
            return self._hip.knows(query_sdr, threshold)

    async def sleep_decay(self) -> int:
        async with self._lock:
            return self._hip.sleep_decay()

    async def stats(self) -> dict:
        async with self._lock:
            return self._hip.stats()

    def close(self) -> None:
        self._hip.close()
