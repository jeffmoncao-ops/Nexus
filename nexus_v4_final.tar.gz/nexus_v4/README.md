# Nexus V2 — Kernel Cognitivo SDR

Sistema cognitivo baseado em **Sparse Distributed Representations (SDR)**.  
Construído do zero com arquitetura modular, estado epistêmico rigoroso e testes reais.

---

## Estrutura

```
nexus_v2/
├── nexus/
│   ├── core/sdr_math.py        # Matemática SDR pura (SparseSDR, MiniEmbed, XORBinding)
│   ├── memory/hippocampus.py   # Hipocampo unificado L1/L2 (SQLite, Hebbiano)
│   ├── cognitive/brains.py     # 8 brains com domain SDR geométrico + GlobalWorkspace
│   ├── cognitive/text_weaver.py # Formatação com estado epistêmico ("não sei" real)
│   └── api/server.py           # FastAPI com /learn /chat /search /health /brains /sleep
├── tests/test_nexus_v2.py      # 69 testes PyTest com validação SQL direta
├── requirements.txt
└── pyproject.toml
```

---

## Instalação

```bash
pip install -r requirements.txt
```

---

## Uso rápido

```python
from nexus import Nexus

nx = Nexus()                       # banco em memória
nx = Nexus(db_path="nexus.db")     # banco persistente
nx = Nexus(web_enabled=True)       # com WebBrain (busca Wikipedia)

# Aprender
r = nx.learn("fotossíntese converte luz solar em glicose usando clorofila")
print(r.stored, r.brain_id)        # True, 'biologia'

# Consultar — estado epistêmico explícito
response = nx.chat("o que é fotossíntese?")
print(response)
# → "fotossíntese converte luz solar em glicose usando clorofila. [biologia]"

# Sistema vazio → admite ignorância
response = nx.chat("o que é um quasar?")
print(response)
# → "Dados insuficientes na memória local."

# Busca direta
hits = nx.search("fotossíntese luz", top_k=3)
# → [(score, text, brain_id), ...]

# Adicionar brain customizado
nx.add_brain("astronomia", "Astronomia",
             "estrela planeta galáxia órbita buraco negro universo")
nx.learn("buraco negro é uma região com gravidade extrema", brain_id="astronomia")

# Sono Hebbiano (decaimento de memórias não acessadas)
nx.sleep()

# Diagnóstico
print(nx.health())
```

---

## Parâmetros do SDR

| Parâmetro | Valor | Descrição |
|---|---|---|
| `SDR_SIZE` | 8192 | Dimensões totais do espaço vetorial |
| `SDR_ACTIVE` | 60 | Bits ativos por SDR (esparsidade ~0.73%) |
| `L1 signature` | 127 bits | Filtro AND bitwise em SQL |
| `Domain SDR` | 360 bits | Assinatura geométrica de cada brain |
| `CONFIDENCE_THRESHOLD` | 0.25 | Jaccard mínimo para resposta confiante |
| `RECALL_THRESHOLD` | 0.05 | Jaccard mínimo para qualquer resultado |

---

## API REST

```bash
# Iniciar servidor
python -c "from nexus.api.server import run; run()"
# → http://127.0.0.1:8000
```

| Endpoint | Método | Descrição |
|---|---|---|
| `/learn` | POST | Aprende um fato |
| `/chat` | POST | Consulta com estado epistêmico |
| `/search` | POST | Busca direta no hipocampo |
| `/health` | GET | Saúde do sistema |
| `/brains` | GET | Status de todos os brains |
| `/sleep` | POST | Decaimento Hebbiano |
| `/web` | POST | Força busca na Wikipedia |

**Exemplo `/chat`:**
```json
POST /chat
{"message": "o que é fotossíntese?", "web_fallback": false}

→ {
    "response": "fotossíntese converte luz solar em glicose. [biologia]",
    "confident": true,
    "score": 0.8333,
    "brain_id": "biologia",
    "latency_ms": 1.2,
    "sdr_sig63": 4611686018427387903
}
```

**Exemplo sem dados:**
```json
→ {
    "response": "Dados insuficientes na memória local.",
    "confident": false,
    "score": 0.0,
    "brain_id": "",
    "latency_ms": 0.8
}
```

---

## Testes

```bash
# Suite completa (69 testes)
python -m pytest tests/ -v

# Com cobertura
pip install pytest-cov
python -m pytest tests/ --cov=nexus --cov-report=term-missing
```

---

## Arquitetura

### Estado Epistêmico Rigoroso
O sistema **nunca inventa**. `QueryResult.confident = False` é o gatilho explícito
para o `WebBrain` — não uma condição implícita.

### Hipocampo Unificado L1/L2
- **L1**: filtro AND bitwise 127-bit em SQL — O(1) com índice
- **L2**: refinamento Jaccard exato 8192-bit em Python
- Conexão persistente única — sem bug de múltiplos `:memory:`

### Domain SDR Geométrico
Cada brain possui uma assinatura de 360 bits gerada por encoding multi-token.
Filtro de domínio via XOR — sem `if "python" in text`.

### Cross-Domain Learning
Busca cross-domain usa o SDR original (sem filtro) para máximo recall.
Todos os brains compartilham o mesmo `Hippocampus`.

### Decaimento Hebbiano
Fatos acessados ganham peso. Fatos antigos e não acessados perdem prioridade.
Nenhum fato é deletado — apenas deprioritizado.
