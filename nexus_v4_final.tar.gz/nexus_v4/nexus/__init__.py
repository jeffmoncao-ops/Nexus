"""
Nexus V4 — CBR + Pool Único + Soft Tags + Taxonomia de Memória
==============================================================
Evolução V4: CaseEngine CBR com ciclo 4R completo.
"""
from nexus.core.sdr_math import SparseSDR, MiniEmbed, XORBinding, VecOps
from nexus.memory.hippocampus import Hippocampus, CONFIDENCE_THRESHOLD
from nexus.cognitive.brains import GlobalWorkspace, QueryResult
from nexus.cognitive.cbr import CaseEngine, CaseResult
from nexus.cognitive.text_weaver import TextWeaver, WebBrain


class Nexus:
    VERSION = "4.0.0"

    def __init__(self, db_path: str = ":memory:", web_enabled: bool = False):
        self._embed     = MiniEmbed()
        self._hip       = Hippocampus(db_path=db_path)
        self._workspace = GlobalWorkspace(self._hip, self._embed)
        self._cbr       = CaseEngine(self._hip, self._embed)
        self._web       = WebBrain(self._workspace) if web_enabled else None
        self._weaver    = TextWeaver(self._workspace, self._cbr, self._web)

    # ── Fatos declarativos/associativos ───────────────────────────────────────
    def learn(self, text: str, brain_id=None,
              weight: float = 1.0, memory_type=None):
        return self._workspace.learn(text.strip(), brain_id=brain_id,
                                      weight=weight, memory_type=memory_type)

    def chat(self, text: str, web_fallback: bool = True) -> str:
        return self._weaver.respond(text.strip(), web_fallback=web_fallback)

    # ── CBR ───────────────────────────────────────────────────────────────────
    def learn_case(self, problem: str, action: str,
                   outcome: float = 0.5, brain: str = None) -> int:
        """Aprende um caso CBR: problema + ação + resultado histórico."""
        return self._cbr.retain(problem, action, outcome_score=outcome, brain=brain)

    def solve(self, problem: str, min_outcome: float = 0.3) -> CaseResult:
        """Consulta CBR: dado um problema, sugere ação do caso mais similar."""
        return self._cbr.retrieve_and_reuse(problem, min_outcome=min_outcome)

    def feedback(self, problem: str, success: bool,
                 outcome: float = None) -> bool:
        """Fornece feedback pós-execução para atualizar o caso."""
        return self._cbr.revise(problem, success, outcome_score=outcome)

    def import_cases(self, cases: list) -> dict:
        """Importa casos em lote: [{'problem':..., 'action':..., 'outcome':...}]"""
        return self._cbr.import_cases(cases)

    # ── Busca e saúde ─────────────────────────────────────────────────────────
    def search(self, text: str, top_k: int = 5):
        return self._hip.recall(self._embed.encode(text), top_k=top_k)

    def search_cases(self, problem: str, top_k: int = 3) -> list:
        return self._cbr.retrieve(problem, top_k=top_k)

    def add_brain(self, brain_id: str, name: str, domain_text: str):
        return self._workspace.add_brain(brain_id, name, domain_text)

    def sleep(self) -> dict:
        return self._workspace.sleep()

    def health(self) -> dict:
        h = self._workspace.health()
        h["cbr"] = self._cbr.stats
        return h

    @property
    def workspace(self) -> GlobalWorkspace: return self._workspace
    @property
    def hippocampus(self) -> Hippocampus:   return self._hip
    @property
    def case_engine(self) -> CaseEngine:    return self._cbr
