"""nexus/api/server.py — V4"""
from __future__ import annotations
import os, time
from contextlib import asynccontextmanager
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from nexus.core.sdr_math import MiniEmbed
from nexus.memory.hippocampus import HippocampusAsync, CONFIDENCE_THRESHOLD
from nexus.cognitive.brains import GlobalWorkspace
from nexus.cognitive.cbr import CaseEngine
from nexus.cognitive.text_weaver import TextWeaver, WebBrain


class AppState:
    embed: MiniEmbed; hip_async: HippocampusAsync
    workspace: GlobalWorkspace; cbr: CaseEngine
    weaver: TextWeaver; web_brain: WebBrain; ready: bool = False

_state = AppState()

def _init_state(db_path: str = "nexus_api.db") -> None:
    global _state
    _state           = AppState()
    _state.embed     = MiniEmbed()
    _state.hip_async = HippocampusAsync(db_path=db_path)
    _state.workspace = GlobalWorkspace(hippocampus=_state.hip_async._hip, embed=_state.embed)
    _state.cbr       = CaseEngine(_state.hip_async._hip, _state.embed)
    _state.web_brain = WebBrain(_state.workspace, timeout=4.0)
    _state.weaver    = TextWeaver(_state.workspace, _state.cbr, _state.web_brain)
    _state.ready     = True

@asynccontextmanager
async def lifespan(app: FastAPI):
    _init_state(db_path=os.environ.get("NEXUS_DB_PATH", "nexus_api.db"))
    print("🚀 Nexus V4 API — online.")
    yield
    _state.hip_async.close()

app = FastAPI(title="Nexus V4 API", version="4.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

def _req():
    if not _state.ready: raise HTTPException(503, "Sistema não inicializado.")

class LearnReq(BaseModel):
    text: str; brain_id: Optional[str] = None
    weight: float = 1.0; memory_type: Optional[str] = None

class CaseReq(BaseModel):
    problem: str; action: str
    outcome: float = 0.5; brain: Optional[str] = None; weight: float = 1.0

class ReviseReq(BaseModel):
    problem: str; success: bool; outcome: Optional[float] = None

class ImportReq(BaseModel):
    cases: List[dict]

class ChatReq(BaseModel):
    message: str; web_fallback: bool = True

class SearchReq(BaseModel):
    query: str; top_k: int = 5
    preferred_brain: Optional[str] = None
    interdisciplinary: bool = False

class SolveReq(BaseModel):
    problem: str; min_outcome: float = 0.3; top_k: int = 3


@app.post("/learn")
async def learn(req: LearnReq):
    _req()
    if not req.text.strip(): raise HTTPException(400, "Texto vazio.")
    result = _state.workspace.learn(req.text.strip(), brain_id=req.brain_id,
                                     weight=req.weight, memory_type=req.memory_type)
    return {"stored": result.stored, "brain_id": result.brain_id,
            "memory_type": result.memory_type, "row_id": result.row_id,
            "message": (f'Aprendi [{result.memory_type}]: "{result.text[:60]}"'
                        if result.stored else "Já conhecia (dedup).")}


@app.post("/cases")
async def learn_case(req: CaseReq):
    """Aprende um caso CBR: problema + ação + outcome."""
    _req()
    if not req.problem.strip() or not req.action.strip():
        raise HTTPException(400, "Problema e ação são obrigatórios.")
    rid = await _state.hip_async.store_case(
        _state.embed.encode(req.problem), req.problem,
        req.action, req.outcome, req.brain or "core", req.weight,
    )
    return {"stored": rid > 0, "row_id": rid,
            "message": (f'Caso CBR aprendido: "{req.problem[:50]}" → "{req.action[:50]}"'
                        if rid > 0 else "Caso similar já existe (dedup).")}


@app.post("/cases/import")
async def import_cases(req: ImportReq):
    """Importa casos em lote."""
    _req()
    result = _state.cbr.import_cases(req.cases)
    return result


@app.post("/cases/solve")
async def solve(req: SolveReq):
    """Consulta CBR: dado um problema, busca ação do caso mais similar."""
    _req()
    results = _state.cbr.retrieve(req.problem, top_k=req.top_k,
                                   min_outcome=req.min_outcome)
    if not results:
        return {"confident": False, "action": "",
                "similarity": 0.0, "outcome_score": 0.0,
                "message": "Nenhum caso similar encontrado."}
    best = results[0]
    return {"confident": best.confident, "action": best.action,
            "similarity": round(best.similarity, 4),
            "outcome_score": round(best.outcome_score, 4),
            "composite_score": round(best.composite_score, 4),
            "problem_text": best.problem_text,
            "message": best.format(),
            "alternatives": [
                {"action": r.action, "similarity": round(r.similarity, 4),
                 "outcome": round(r.outcome_score, 4)}
                for r in results[1:]
            ]}


@app.post("/cases/revise")
async def revise(req: ReviseReq):
    """Atualiza outcome de um caso após execução."""
    _req()
    ok = await _state.hip_async.revise_case(req.problem, req.outcome or (1.0 if req.success else 0.0))
    return {"updated": ok, "success": req.success}


@app.post("/chat")
async def chat(req: ChatReq):
    _req()
    t0       = time.perf_counter()
    sdr      = _state.embed.encode(req.message)
    response = _state.weaver.respond(req.message, web_fallback=req.web_fallback)
    elapsed  = time.perf_counter() - t0
    result   = _state.workspace.query(req.message)
    return {"response": response, "confident": result.confident,
            "score": round(result.score, 4), "brain_id": result.brain_id,
            "memory_type": result.memory_type,
            "latency_ms": round(elapsed*1000, 1),
            "sdr_sig63": sdr.to_hex_signature()}


@app.post("/search")
async def search(req: SearchReq):
    _req()
    sdr = _state.embed.encode(req.query)
    if req.interdisciplinary:
        results = _state.workspace.query_interdisciplinary(req.query, top_k=req.top_k)
        hits = [{"score": round(r.score, 4), "text": r.text,
                 "brain": r.brain_id, "type": r.memory_type} for r in results]
    else:
        raw  = await _state.hip_async.recall(sdr, top_k=req.top_k,
                                              preferred_brain=req.preferred_brain)
        hits = [{"score": round(s, 4), "text": t, "brain": b, "type": m}
                for s, t, b, m in raw]
    return {"query": req.query, "hits": hits,
            "confidence_threshold": CONFIDENCE_THRESHOLD}


@app.get("/health")
async def health():
    _req()
    h = _state.workspace.health()
    h["cbr"] = _state.cbr.stats
    return {"status": "online", "version": "4.0.0", "ready": True, "system": h}


@app.get("/brains")
async def brains():
    _req()
    return {"count": len(_state.workspace._brains),
            "status": _state.workspace.brain_status(),
            "brains": {bid: b.stats for bid, b in _state.workspace._brains.items()}}


@app.post("/sleep")
async def sleep():
    _req()
    return _state.workspace.sleep()

def run(host: str = "127.0.0.1", port: int = 8000):
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="info")
