"""
nexus/cognitive/brains.py — V3
================================
GlobalWorkspace com Pool Único + Soft Tags.

Evoluções em relação ao V2:
  1. Sem XOR domain filter nas queries
     - SDR original sempre usado para busca
     - Conceitos inter-disciplinares encontrados sem penalidade geométrica

  2. Soft domain preference passado como hint, não como filtro
     - preferred_brain → boost de +DOMAIN_BOOST no score
     - Cross-domain acontece naturalmente (não precisa de flag especial)

  3. Taxonomia de memória integrada
     - learn() aceita memory_type explícito ou infere automaticamente
     - query() pode preferir um tipo de memória (soft)

  4. Domain SDR mantido para domain_relevance()
     - Continua útil para ranquear brains candidatos
     - Não é mais usado para transformar o vetor de busca
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from nexus.core.sdr_math import MiniEmbed, SparseSDR, XORBinding, SDR_ACTIVE, SDR_SIZE
from nexus.memory.hippocampus import (
    Hippocampus, MemoryType, _infer_memory_type,
    CONFIDENCE_THRESHOLD, RECALL_THRESHOLD, DOMAIN_BOOST,
)


@dataclass
class QueryResult:
    """
    Resultado de consulta com estado epistêmico explícito e metadados de proveniência.
    confident=False é o gatilho para o WebBrain.
    """
    text:        str
    score:       float
    brain_id:    str
    memory_type: str
    confident:   bool

    def __bool__(self) -> bool:
        return self.confident


@dataclass
class LearnResult:
    stored:      bool
    text:        str
    brain_id:    str
    memory_type: str
    row_id:      int    # 0 = duplicata


class SpecialistBrain:
    """
    Cérebro especialista V3.

    Domain SDR: ainda gerado, mas usado APENAS para domain_relevance().
    NÃO transforma o vetor de busca.
    Busca sempre no hipocampo compartilhado com preferred_brain como soft hint.
    """

    def __init__(self, brain_id: str, name: str, domain_text: str,
                 embed: MiniEmbed, hippocampus: Hippocampus):
        self.id         = brain_id
        self.name       = name
        self._embed     = embed
        self._hip       = hippocampus
        self.domain_sdr = self._build_domain_sdr(embed, domain_text)
        self._learned   = 0
        self._queried   = 0
        self._confident = 0

    @staticmethod
    def _build_domain_sdr(embed: MiniEmbed, domain_text: str) -> SparseSDR:
        """360 bits acumulados dos tokens do domínio → assinatura geométrica."""
        tokens   = list(set(__import__('re').findall(r'\w{3,}', domain_text.lower())))[:20]
        all_bits: set = set()
        for tok in tokens:
            all_bits.update(embed.encode(tok)._idx)
        lst  = sorted(all_bits)
        n    = SDR_ACTIVE * 6
        step = max(1, len(lst) // n)
        return SparseSDR(lst[::step][:n])

    def domain_relevance(self, query_sdr: SparseSDR) -> float:
        """Jaccard entre query e domain_sdr. Score geométrico, sem keywords."""
        return query_sdr.jaccard(self.domain_sdr)

    def learn(self, text: str, weight: float = 1.0,
              memory_type: Optional[MemoryType] = None) -> LearnResult:
        sdr   = self._embed.encode(text)
        mtype = memory_type or _infer_memory_type(text)
        rid   = self._hip.store(sdr, text, brain=self.id, weight=weight, memory_type=mtype)
        if rid > 0:
            self._learned += 1
        return LearnResult(stored=rid > 0, text=text, brain_id=self.id,
                            memory_type=mtype, row_id=rid)

    def query(self, text: str, top_k: int = 3,
              preferred_type: Optional[MemoryType] = None) -> List[QueryResult]:
        """
        Busca no hipocampo compartilhado com soft brain preference.
        Sem XOR domain filter — SDR original usado diretamente.
        Conceitos inter-disciplinares emergem naturalmente.
        """
        self._queried += 1
        query_sdr = self._embed.encode(text)

        # Soft preference: este brain como hint, não como filtro
        hits = self._hip.recall(
            query_sdr, top_k=top_k,
            preferred_brain=self.id,
            preferred_type=preferred_type,
            min_jaccard=RECALL_THRESHOLD,
        )

        results = []
        for score, text_hit, brain_hit, mtype in hits:
            confident = score >= CONFIDENCE_THRESHOLD
            if confident:
                self._confident += 1
            results.append(QueryResult(
                text=text_hit, score=score, brain_id=brain_hit,
                memory_type=mtype, confident=confident,
            ))
        return results

    def knows(self, text: str) -> bool:
        q = self._embed.encode(text)
        return self._hip.knows(q)

    @property
    def stats(self) -> dict:
        facts = len(self._hip.all_facts(brain_filter=self.id))
        return {
            "id": self.id, "name": self.name, "facts": facts,
            "learned": self._learned, "queried": self._queried,
            "confident": self._confident,
        }


DEFAULT_DOMAINS: List[Dict] = [
    {
        "id":   "biologia",
        "name": "Biologia e Ciências da Vida",
        "text": ("célula dna rna proteína evolução organismo fotossíntese "
                 "mitose meiose genética cromossomo metabolismo enzima "
                 "vírus bactéria ecossistema biodiversidade genoma"),
    },
    {
        "id":   "fisica",
        "name": "Física",
        "text": ("átomo partícula elétron força energia gravidade velocidade "
                 "massa onda frequência calor temperatura termodinâmica "
                 "eletricidade magnetismo relatividade quantum fóton"),
    },
    {
        "id":   "matematica",
        "name": "Matemática",
        "text": ("número função equação integral derivada logaritmo "
                 "probabilidade estatística geometria álgebra cálculo "
                 "teorema número primo matrix vetor limite série"),
    },
    {
        "id":   "tecnologia",
        "name": "Tecnologia e Computação",
        "text": ("programação código software algoritmo computador sistema "
                 "python javascript banco dados rede internet api servidor "
                 "inteligência artificial machine learning compilador memória"),
    },
    {
        "id":   "medicina",
        "name": "Medicina e Saúde",
        "text": ("doença sintoma diagnóstico tratamento medicamento vacina "
                 "infecção imunidade anticorpo órgão coração pulmão "
                 "câncer diabetes cirurgia nutrição hormônio epidemia"),
    },
    {
        "id":   "historia",
        "name": "História",
        "text": ("guerra revolução império civilização descoberta colônia "
                 "política governo presidente século democracia ditadura "
                 "colonialismo independência tratado renascimento"),
    },
    {
        "id":   "geografia",
        "name": "Geografia",
        "text": ("brasil amazônia continente país capital cidade oceano "
                 "montanha clima bioma floresta cerrado território "
                 "população migração urbanização região"),
    },
    {
        "id":   "linguistica",
        "name": "Linguística e Literatura",
        "text": ("língua gramática sintaxe semântica fonologia morfologia "
                 "texto discurso comunicação português literatura poema "
                 "metáfora analogia linguagem escrita autor"),
    },
]


class GlobalWorkspace:
    """
    Orquestrador V3 — Pool Único + Soft Tags.

    Princípio central:
      Todos os fatos vivem no mesmo hipocampo.
      Domínio é metadata de origem, não barreira de busca.
      Conceitos inter-disciplinares são automaticamente acessíveis por todos os brains.

    Fluxo:
      learn(text) → infere brain + memory_type → store no hipocampo
      query(text) → busca no banco inteiro → soft boost por preferred_brain
                  → confident=True ou confident=False (gatilho WebBrain)
    """

    def __init__(self, hippocampus: Hippocampus, embed: MiniEmbed,
                 domains: Optional[List[Dict]] = None):
        self._hip    = hippocampus
        self._embed  = embed
        self._xor    = XORBinding(embed)
        self._brains: Dict[str, SpecialistBrain] = {}
        self._stats  = {
            "learned": 0, "queries": 0,
            "confident_hits": 0, "uncertain_hits": 0,
            "propagations": 0, "sleep_cycles": 0,
        }

        for d in (domains if domains is not None else DEFAULT_DOMAINS):
            self._brains[d["id"]] = SpecialistBrain(
                brain_id=d["id"], name=d["name"],
                domain_text=d["text"], embed=embed, hippocampus=hippocampus,
            )

    def learn(self, text: str, brain_id: Optional[str] = None,
              weight: float = 1.0,
              memory_type: Optional[MemoryType] = None) -> LearnResult:
        """
        Aprende um fato.
        brain_id determina a tag de origem (metadado), não onde o fato é armazenado.
        O armazenamento sempre vai para o hipocampo compartilhado.
        Se brain_id não fornecido: usa domain_relevance para escolher o mais próximo.
        """
        sdr    = self._embed.encode(text)
        target = brain_id or self._best_brain(sdr)
        mtype  = memory_type or _infer_memory_type(text)

        if target and target in self._brains:
            result = self._brains[target].learn(text, weight, mtype)
        else:
            rid    = self._hip.store(sdr, text, brain="core", weight=weight, memory_type=mtype)
            result = LearnResult(stored=rid > 0, text=text, brain_id="core",
                                  memory_type=mtype, row_id=rid)

        if result.stored:
            self._stats["learned"] += 1
            if target and target != brain_id:
                self._stats["propagations"] += 1

        return result

    def query(self, text: str, top_k: int = 3,
              preferred_brain: Optional[str] = None,
              preferred_type:  Optional[MemoryType] = None) -> QueryResult:
        """
        Consulta no pool único com soft preference.
        Sem barreira de domínio. Conceitos inter-disciplinares emergem naturalmente.
        """
        self._stats["queries"] += 1
        query_sdr = self._embed.encode(text)

        # Se preferred_brain não especificado, infere pelo domain_relevance
        if not preferred_brain:
            preferred_brain = self._best_brain(query_sdr)

        hits = self._hip.recall(
            query_sdr, top_k=top_k,
            preferred_brain=preferred_brain,
            preferred_type=preferred_type,
            min_jaccard=RECALL_THRESHOLD,
        )

        if hits:
            score, text_hit, brain_hit, mtype = hits[0]
            confident = score >= CONFIDENCE_THRESHOLD
            self._stats["confident_hits" if confident else "uncertain_hits"] += 1
            return QueryResult(text=text_hit, score=score, brain_id=brain_hit,
                                memory_type=mtype, confident=confident)

        self._stats["uncertain_hits"] += 1
        return QueryResult(text="", score=0.0, brain_id="", memory_type="", confident=False)

    def query_interdisciplinary(self, text: str, top_k: int = 5) -> List[QueryResult]:
        """
        Busca explicitamente inter-disciplinar: sem soft preference de domínio.
        Retorna os top_k mais similares do banco inteiro, sem boost.
        Ideal para perguntas que cruzam domínios (ex: redes neurais artificiais).
        """
        self._stats["queries"] += 1
        query_sdr = self._embed.encode(text)
        hits      = self._hip.recall(
            query_sdr, top_k=top_k,
            preferred_brain=None, preferred_type=None,
            min_jaccard=RECALL_THRESHOLD,
        )
        return [
            QueryResult(text=t, score=s, brain_id=b, memory_type=m,
                        confident=s >= CONFIDENCE_THRESHOLD)
            for s, t, b, m in hits
        ]

    def add_brain(self, brain_id: str, name: str, domain_text: str) -> SpecialistBrain:
        brain = SpecialistBrain(
            brain_id=brain_id, name=name, domain_text=domain_text,
            embed=self._embed, hippocampus=self._hip,
        )
        self._brains[brain_id] = brain
        return brain

    def remove_brain(self, brain_id: str) -> bool:
        if brain_id in self._brains:
            del self._brains[brain_id]
            return True
        return False

    def sleep(self) -> dict:
        self._stats["sleep_cycles"] += 1
        affected = self._hip.sleep_decay()
        return {"sleep_cycle": self._stats["sleep_cycles"], "decayed_facts": affected}

    def brain_status(self) -> str:
        lines = ["Brains ativos (pool unificado):"]
        for b in self._brains.values():
            s = b.stats
            lines.append(
                f"  [{s['id']:12s}] {s['name']:30s} "
                f"fatos={s['facts']:4d}  "
                f"aprendidos={s['learned']:4d}  "
                f"confiantes={s['confident']:4d}"
            )
        return "\n".join(lines)

    def health(self) -> dict:
        return {
            "hippocampus": self._hip.stats(),
            "brains":      {bid: b.stats for bid, b in self._brains.items()},
            "stats":       self._stats,
        }

    def _best_brain(self, sdr: SparseSDR) -> Optional[str]:
        """Domain_relevance geométrico — sem keyword matching."""
        best_id, best_score = None, 0.0
        for bid, brain in self._brains.items():
            rel = brain.domain_relevance(sdr)
            if rel > best_score:
                best_score, best_id = rel, bid
        return best_id if best_score > 0.02 else None
