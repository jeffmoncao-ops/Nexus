"""
nexus/cognitive/cbr.py
======================
CaseEngine — Motor de Raciocínio Baseado em Casos (CBR).

Implementa o ciclo 4R completo sobre o Hippocampus V4:

  RETRIEVE  → Dado um problema, busca casos similares geometricamente (Jaccard SDR)
  REUSE     → Se similaridade >= CBR_CONFIDENCE, propõe a ação do caso mais próximo
  REVISE    → Recebe feedback de sucesso/falha e atualiza outcome_score
  RETAIN    → Armazena o novo caso se for suficientemente diferente dos existentes

Diferença do CBR por palavras-chave:
  "Calor excessivo" e "Temperatura alta" têm SDRs vizinhos no espaço 8192D.
  O sistema encontra o caso correto mesmo com vocabulário diferente.

Estado epistêmico preservado:
  Se não há caso similar, CaseResult.confident = False.
  Não inventa ações — diz explicitamente que não tem caso para a situação.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from nexus.core.sdr_math import MiniEmbed, SparseSDR
from nexus.memory.hippocampus import (
    Hippocampus, CBR_CONFIDENCE, RECALL_THRESHOLD,
)


@dataclass
class CaseResult:
    """Resultado de uma consulta CBR com estado epistêmico explícito."""
    problem_text:   str
    action:         str
    similarity:     float     # Jaccard do problema com o caso recuperado
    outcome_score:  float     # histórico de sucesso do caso [0..1]
    composite_score: float    # score final (similaridade × peso × outcome)
    confident:      bool      # True se composite_score >= CBR_CONFIDENCE

    def __bool__(self) -> bool:
        return self.confident

    def format(self) -> str:
        if not self.confident:
            return "Nenhum caso similar encontrado. Situação nova — sem ação sugerida."
        pct  = f"{self.similarity*100:.0f}%"
        hist = f"{self.outcome_score*100:.0f}%"
        return (f"[CBR] Caso similar encontrado ({pct} de similaridade, "
                f"histórico de sucesso: {hist}).\n"
                f"Ação sugerida: {self.action}")


class CaseEngine:
    """
    Motor CBR sobre o Hippocampus V4.

    Uso:
        engine = CaseEngine(hippocampus, embed)

        # Aprender um caso
        engine.retain("temperatura do sensor acima de 80°C",
                       action="ligar sistema de resfriamento",
                       outcome_score=0.95)

        # Consultar
        result = engine.retrieve_and_reuse("sensor de calor disparando alarme")
        if result.confident:
            print(result.format())  # ação sugerida
        else:
            print("Situação nova, não há caso similar.")

        # Feedback pós-execução
        engine.revise("temperatura do sensor acima de 80°C", success=True)
    """

    # Threshold mínimo de similaridade para sugerir ação
    CONFIDENCE = CBR_CONFIDENCE
    # Novos casos só são retidos se distância > este valor (evita duplicatas)
    NOVELTY_THRESHOLD = 0.70

    def __init__(self, hippocampus: Hippocampus, embed: MiniEmbed,
                 default_brain: str = "core"):
        self._hip   = hippocampus
        self._embed = embed
        self._brain = default_brain
        self._stats = {
            "retrieves":  0,
            "hits":       0,
            "misses":     0,
            "retains":    0,
            "revisions":  0,
        }

    # ── R1: RETRIEVE — Recuperação por Similaridade Geométrica ────────────────

    def retrieve(self, problem: str,
                 top_k: int = 3,
                 min_outcome: float = 0.0) -> List[CaseResult]:
        """
        Recupera os casos mais similares ao problema.
        Retorna lista ordenada por composite_score decrescente.
        """
        self._stats["retrieves"] += 1
        problem_sdr = self._embed.encode(problem)

        hits = self._hip.recall_cases(
            problem_sdr, top_k=top_k,
            min_jaccard=RECALL_THRESHOLD,
            min_outcome=min_outcome,
        )

        if not hits:
            self._stats["misses"] += 1
            return []

        results = []
        for score, case_text, action, outcome in hits:
            # Calcula Jaccard real separado do score composto
            case_sdr    = self._embed.encode(case_text)
            raw_jaccard = problem_sdr.jaccard(case_sdr)
            confident   = score >= self.CONFIDENCE
            if confident:
                self._stats["hits"] += 1
            results.append(CaseResult(
                problem_text    = case_text,
                action          = action,
                similarity      = raw_jaccard,
                outcome_score   = outcome,
                composite_score = score,
                confident       = confident,
            ))

        return results

    # ── R1+R2: RETRIEVE + REUSE — Consulta completa ────────────────────────────

    def retrieve_and_reuse(self, problem: str,
                           min_outcome: float = 0.3) -> CaseResult:
        """
        Consulta principal: recupera o melhor caso e propõe ação.
        min_outcome filtra casos com histórico de falha.
        """
        hits = self.retrieve(problem, top_k=1, min_outcome=min_outcome)

        if not hits:
            return CaseResult(
                problem_text="", action="", similarity=0.0,
                outcome_score=0.0, composite_score=0.0, confident=False,
            )
        return hits[0]

    # ── R3: REVISE — Feedback pós-execução ────────────────────────────────────

    def revise(self, problem_text: str, success: bool,
               outcome_score: Optional[float] = None) -> bool:
        """
        Atualiza o outcome_score após execução da ação.
        success=True  → outcome 1.0 (ou valor explícito)
        success=False → outcome 0.0 (ou valor explícito)
        """
        self._stats["revisions"] += 1
        if outcome_score is None:
            outcome_score = 1.0 if success else 0.0
        return self._hip.revise_case(problem_text, outcome_score)

    # ── R4: RETAIN — Retenção de novos casos ──────────────────────────────────

    def retain(self, problem: str, action: str,
               outcome_score: float = 0.5,
               brain: str = None,
               weight: float = 1.0) -> int:
        """
        Retém um novo caso se for suficientemente diferente dos existentes.
        Evita duplicatas geométricas (NOVELTY_THRESHOLD).
        Retorna id inserido ou 0 se caso similar já existe.
        """
        brain = brain or self._brain
        problem_sdr = self._embed.encode(problem)

        # Verifica novelty: se há caso >= NOVELTY_THRESHOLD, não retém
        existing = self._hip.recall_cases(
            problem_sdr, top_k=1, min_jaccard=0.0
        )
        if existing:
            best_score, _, _, _ = existing[0]
            # score = j * weight * (0.5+0.5*outcome); extraímos Jaccard aproximado
            # Se o case_text é quase idêntico, jaccard será alto
            case_text    = existing[0][1]
            case_sdr     = self._embed.encode(case_text)
            raw_jaccard  = problem_sdr.jaccard(case_sdr)
            if raw_jaccard >= self.NOVELTY_THRESHOLD:
                return 0  # não é um caso novo suficientemente diferente

        rid = self._hip.store_case(
            problem_sdr, problem, action,
            outcome_score=outcome_score, brain=brain, weight=weight,
        )
        if rid > 0:
            self._stats["retains"] += 1
        return rid

    # ── Importação em lote ─────────────────────────────────────────────────────

    def import_cases(self, cases: list) -> dict:
        """
        Importa casos no formato:
        [{"problem": "...", "action": "...", "outcome": 0.9, "brain": "..."}]

        Retorna relatório de importação.
        """
        imported = 0
        skipped  = 0
        for case in cases:
            rid = self.retain(
                problem       = case["problem"],
                action        = case["action"],
                outcome_score = case.get("outcome", 0.5),
                brain         = case.get("brain", self._brain),
                weight        = case.get("weight", 1.0),
            )
            if rid > 0:
                imported += 1
            else:
                skipped += 1
        return {"imported": imported, "skipped": skipped, "total": len(cases)}

    @property
    def stats(self) -> dict:
        return {**self._stats, "cbr_threshold": self.CONFIDENCE}
