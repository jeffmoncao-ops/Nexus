"""
nexus/cognitive/text_weaver.py — V4
Formata respostas por tipo: declarativa, procedural/CBR, associativa.
"""
from __future__ import annotations
import re
from typing import Optional
from nexus.cognitive.brains import GlobalWorkspace, QueryResult
from nexus.cognitive.cbr import CaseEngine, CaseResult

_INSUFFICIENT = "Dados insuficientes na memória local."
_LEARNED      = 'Aprendi ({mtype}): "{text}"'
_DUPLICATE    = '[dedup] Já conheço algo similar: "{text}"'


class TextWeaver:
    def __init__(self, workspace: GlobalWorkspace,
                 case_engine:  Optional[CaseEngine] = None,
                 web_brain:    Optional["WebBrain"] = None):
        self._ws     = workspace
        self._cbr    = case_engine
        self._web    = web_brain

    def respond(self, query: str, web_fallback: bool = True) -> str:
        """
        Fluxo V4:
          1. Tenta CBR primeiro (se case_engine disponível)
          2. Se CBR não confiante, tenta memória declarativa/associativa
          3. Se nenhuma, tenta WebBrain
          4. Último recurso: "Dados insuficientes"
        """
        # 1. CBR — para problemas com ação recomendada
        if self._cbr is not None:
            cbr_result = self._cbr.retrieve_and_reuse(query, min_outcome=0.3)
            if cbr_result.confident:
                return cbr_result.format()

        # 2. Memória declarativa/associativa
        result = self._ws.query(query)
        if result.confident:
            return self._format_hit(result)

        # 3. WebBrain
        if web_fallback and self._web is not None:
            learned = self._web.fetch_and_learn(query)
            if learned:
                result2 = self._ws.query(query)
                if result2.confident:
                    return f"🌐 [Web] {self._format_hit(result2)}"
                return f"🌐 [Web] Aprendi recentemente: {learned[:300]}"

        return _INSUFFICIENT

    def learn_and_respond(self, text: str, memory_type=None) -> str:
        result = self._ws.learn(text, memory_type=memory_type)
        if result.row_id == 0:
            best = self._ws.query(text)
            return _DUPLICATE.format(text=best.text[:60] if best.text else text[:60])
        return _LEARNED.format(mtype=result.memory_type, text=text[:80])

    def _format_hit(self, result: QueryResult) -> str:
        text = result.text.strip()
        if not text:
            return _INSUFFICIENT
        if text[-1] not in ".!?":
            text += "."
        parts = []
        if result.brain_id:   parts.append(result.brain_id)
        if result.memory_type: parts.append(result.memory_type)
        suffix = f" [{'/'.join(parts)}]" if parts else ""
        return f"{text}{suffix}"


class WebBrain:
    def __init__(self, workspace: GlobalWorkspace, timeout: float = 4.0):
        self._ws      = workspace
        self._timeout = timeout
        self.active   = True

    def fetch_and_learn(self, query: str) -> Optional[str]:
        if not self.active:
            return None
        words = sorted(re.findall(r'\w{4,}', query.lower()), key=len, reverse=True)
        if not words:
            return None
        topic = words[0]
        try:
            import urllib.request, json, urllib.parse
            url = f"https://pt.wikipedia.org/api/rest_v1/page/summary/{urllib.parse.quote(topic)}"
            req = urllib.request.Request(url, headers={"User-Agent": "NexusV4/1.0"})
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                data    = json.loads(resp.read().decode())
                extract = data.get("extract", "").strip()
                if extract and len(extract) > 30:
                    self._ws.learn(extract, weight=2.0)
                    return extract
        except Exception:
            pass
        return None
