# nexus/core/__init__.py
from nexus.core.sdr_math import (
    SparseSDR, MiniEmbed, XORBinding, VecOps,
    SDR_SIZE, SDR_ACTIVE, HAS_NUMPY,
)

__all__ = [
    "SparseSDR", "MiniEmbed", "XORBinding", "VecOps",
    "SDR_SIZE", "SDR_ACTIVE", "HAS_NUMPY",
]
