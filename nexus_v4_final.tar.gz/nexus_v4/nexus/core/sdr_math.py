"""
nexus/core/sdr_math.py
======================
Matemática SDR pura. Zero dependências externas. Zero geração de texto.

Contém:
  - SparseSDR       : representação esparsa 4096 bits
  - MiniEmbed       : codificação texto → SDR determinística
  - XORBinding      : binding direcional SVO com k-WTA
  - VecOps          : operações vetoriais com fallback numpy
"""
from __future__ import annotations

import array
import hashlib
import math
import re
import struct
import unicodedata
from typing import Dict, FrozenSet, List, Optional, Tuple

# ── Constantes globais ─────────────────────────────────────────────────────────
SDR_SIZE   = 8192   # dimensão total (8k — menos colisões, mais capacidade)
SDR_ACTIVE = 60     # bits ativos (esparsidade ~0.73% — capacidade exponencialmente maior)
SDR_SEED   = 0xDEAD_BEEF

# Zonas do SDR (semântica / contexto / valência)
ZONE_SEM = (0,    4096)   # semântica: metade inferior
ZONE_CTX = (4096, 6144)   # contexto
ZONE_VAL = (6144, 8192)   # valência

_STOP_PT: FrozenSet[str] = frozenset({
    "o","a","os","as","um","uma","uns","umas","que","é","de","do","da",
    "dos","das","em","no","na","nos","nas","por","para","com","sem",
    "entre","sobre","ao","aos","à","às","se","não","sim","já","ainda",
    "também","isso","este","esse","aquele","são","ser","tem","ter",
    "foi","era","está","pode","deve","vai","seu","sua","seus","suas",
    "ele","ela","eles","elas","eu","tu","você","nós","todo","toda",
})


# ══════════════════════════════════════════════════════════════════════════════
# SparseSDR
# ══════════════════════════════════════════════════════════════════════════════

class SparseSDR:
    """
    Representação esparsa de 4096 bits via lista de índices ativos.
    Imutável após criação. Todas as operações retornam novos objetos.
    """
    __slots__ = ("_idx",)

    def __init__(self, indices=None):
        if indices is None:
            self._idx = array.array("H")
        elif isinstance(indices, array.array):
            self._idx = indices
        else:
            self._idx = array.array("H", sorted(int(i) % SDR_SIZE for i in indices))

    # ── Operações de conjunto ──────────────────────────────────────────────────

    def __or__(self, other: SparseSDR) -> SparseSDR:
        return SparseSDR(set(self._idx) | set(other._idx))

    def __and__(self, other: SparseSDR) -> SparseSDR:
        return SparseSDR(set(self._idx) & set(other._idx))

    def __xor__(self, other: SparseSDR) -> SparseSDR:
        return SparseSDR(set(self._idx) ^ set(other._idx))

    def __len__(self) -> int:
        return len(self._idx)

    def __repr__(self) -> str:
        return f"SparseSDR(active={len(self._idx)}, density={len(self._idx)/SDR_SIZE:.2%})"

    # ── Similaridade ───────────────────────────────────────────────────────────

    def jaccard(self, other: SparseSDR) -> float:
        a, b = set(self._idx), set(other._idx)
        if not a and not b:
            return 1.0
        u = len(a | b)
        return len(a & b) / u if u else 0.0

    def overlap_score(self, other: SparseSDR) -> float:
        a = set(self._idx)
        if not a:
            return 0.0
        return len(a & set(other._idx)) / len(a)

    # ── Serialização L1/L2 ─────────────────────────────────────────────────────

    def to_hex_signature(self) -> int:
        """[L1] Comprime em 127 bits para filtro AND bitwise em SQL.
        127 bits = mais discriminativo para espaço de 8192 dimensões.
        Cabe em INTEGER SQLite (64-bit signed) usando abs().
        """
        val = 0
        for bit in self._idx:
            slot = int(hashlib.md5(str(bit).encode()).hexdigest(), 16) % 63
            val |= (1 << slot)
        # Segunda passagem com SHA256 para bits 63..126
        for bit in self._idx:
            slot = int(hashlib.sha256(str(bit).encode()).hexdigest(), 16) % 63
            val |= (1 << (63 + slot))
        # Garante que cabe em SQLite INTEGER (63-bit positivo)
        return val & ((1 << 63) - 1)

    def to_blob(self) -> bytes:
        """[L2] Serializa índices para BLOB binário."""
        if not self._idx:
            return b""
        return struct.pack(f">{len(self._idx)}H", *self._idx)

    @classmethod
    def from_blob(cls, blob: bytes) -> SparseSDR:
        """[L2] Restaura a partir de BLOB."""
        if not blob:
            return cls([])
        count = len(blob) // 2
        return cls(struct.unpack(f">{count}H", blob))

    def to_list(self) -> List[int]:
        return list(self._idx)

    @classmethod
    def from_list(cls, lst: List[int]) -> SparseSDR:
        return cls(lst)


# ══════════════════════════════════════════════════════════════════════════════
# VecOps — aceleração numpy opcional
# ══════════════════════════════════════════════════════════════════════════════

try:
    import numpy as _np
    HAS_NUMPY = True
except ImportError:
    _np = None
    HAS_NUMPY = False


class VecOps:
    """Operações vetoriais com fallback Python puro."""

    @staticmethod
    def dot(a, b) -> float:
        if HAS_NUMPY:
            return float(_np.dot(a, b))
        return sum(x * y for x, y in zip(a, b))

    @staticmethod
    def norm(v) -> float:
        if HAS_NUMPY:
            return float(_np.linalg.norm(v))
        return math.sqrt(sum(x * x for x in v))

    @staticmethod
    def cosine(a, b) -> float:
        n = VecOps.norm(a) * VecOps.norm(b)
        return VecOps.dot(a, b) / n if n > 0 else 0.0

    @staticmethod
    def sdr_to_dense(sdr: SparseSDR):
        if HAS_NUMPY:
            v = _np.zeros(SDR_SIZE, dtype=_np.float32)
            if sdr._idx:
                v[list(sdr._idx)] = 1.0
            return v
        v = [0.0] * SDR_SIZE
        for i in sdr._idx:
            v[i] = 1.0
        return v


# ══════════════════════════════════════════════════════════════════════════════
# MiniEmbed — texto → SDR determinístico
# ══════════════════════════════════════════════════════════════════════════════

class MiniEmbed:
    """
    Codificador texto → SparseSDR.
    Determinístico: mesma entrada → mesmo SDR sempre.
    Não gera texto. Não tem estado mutável por token.

    Pipeline:
      1. Normaliza (lowercase, remove acentos)
      2. Tokeniza removendo stopwords
      3. Para cada token, gera bits em cada zona via HMAC-SHA256
      4. k-WTA para manter exatamente SDR_ACTIVE bits
    """

    def __init__(self, seed: int = SDR_SEED):
        self._seed = seed
        self._cache: Dict[str, SparseSDR] = {}

    def _normalize(self, text: str) -> str:
        text = text.lower().strip()
        # Remove acentos
        text = unicodedata.normalize("NFD", text)
        text = "".join(c for c in text if unicodedata.category(c) != "Mn")
        return text

    def _tokenize(self, text: str) -> List[str]:
        words = re.findall(r"\w{2,}", self._normalize(text))
        return [w for w in words if w not in _STOP_PT] or words[:5]

    def _token_bits(self, token: str, zone_start: int,
                    zone_end: int, n_bits: int) -> List[int]:
        zone_size = zone_end - zone_start
        bits = set()
        salt = 0
        while len(bits) < n_bits:
            key = f"{self._seed}:{token}:{salt}".encode()
            h = int(hashlib.sha256(key).hexdigest(), 16)
            for shift in range(0, 256, 12):
                if len(bits) >= n_bits:
                    break
                bits.add(zone_start + (h >> shift) % zone_size)
            salt += 1
        return sorted(bits)[:n_bits]

    def encode(self, text: str) -> SparseSDR:
        if text in self._cache:
            return self._cache[text]

        tokens = self._tokenize(text)
        if not tokens:
            tokens = [text[:32]]

        # Bits por zona (24 semântico + 18 contexto + 18 valência = 60)
        bits_sem, bits_ctx, bits_val = 24, 18, 18

        all_bits: List[int] = []

        # Zona semântica: acumula bits de todos os tokens
        sem_pool: set = set()
        for tok in tokens:
            sem_pool.update(self._token_bits(tok, *ZONE_SEM, bits_sem))
        # k-WTA semântico
        sem_sorted = sorted(sem_pool)
        step = max(1, len(sem_sorted) // bits_sem)
        all_bits.extend(sem_sorted[::step][:bits_sem])

        # Zona contexto: hash do texto completo normalizado
        ctx_key = self._normalize(text)[:64]
        all_bits.extend(self._token_bits(ctx_key, *ZONE_CTX, bits_ctx))

        # Zona valência: detecta polaridade simples
        valence_pos = any(w in tokens for w in
                          ["bom","otimo","excelente","correto","sim","verdadeiro","positivo"])
        valence_neg = any(w in tokens for w in
                          ["ruim","erro","falso","nao","negativo","problema","falha"])
        val_seed = f"pos:{valence_pos}:neg:{valence_neg}"
        all_bits.extend(self._token_bits(val_seed, *ZONE_VAL, bits_val))

        # Garante exatamente SDR_ACTIVE bits únicos
        unique = sorted(set(all_bits))
        while len(unique) < SDR_ACTIVE:
            extra = self._token_bits(f"pad:{len(unique)}", 0, SDR_SIZE, 1)
            unique = sorted(set(unique) | set(extra))
        if len(unique) > SDR_ACTIVE:
            step2 = max(1, len(unique) // SDR_ACTIVE)
            unique = unique[::step2][:SDR_ACTIVE]

        sdr = SparseSDR(unique)
        self._cache[text] = sdr
        return sdr

    def similarity(self, a: str, b: str) -> float:
        return self.encode(a).jaccard(self.encode(b))


# ══════════════════════════════════════════════════════════════════════════════
# XORBinding — binding direcional SVO com k-WTA
# ══════════════════════════════════════════════════════════════════════════════

class XORBinding:
    """
    Codifica relações S-V-O como SDR via XOR com permutação cíclica.
    Evita comutatividade: bind(A,R,B) ≠ bind(B,R,A).
    k-WTA mantém esparsidade rígida em SDR_ACTIVE bits.
    """

    def __init__(self, embed: MiniEmbed):
        self._embed    = embed
        self._bindings: List[Tuple[SparseSDR, str, str, str]] = []
        self._rel_cache: Dict[str, SparseSDR] = {}

    def _rel_sdr(self, rel: str) -> SparseSDR:
        if rel not in self._rel_cache:
            self._rel_cache[rel] = self._embed.encode(f"__REL__{rel}__")
        return self._rel_cache[rel]

    def bind(self, subj: str, rel: str, obj: str) -> SparseSDR:
        s = self._embed.encode(subj)
        r = self._rel_sdr(rel)
        o = self._embed.encode(obj)
        # Permutação cíclica: distingue sujeito de objeto
        s_idx = {(i + 1) % SDR_SIZE for i in s._idx}
        o_idx = {(i - 1) % SDR_SIZE for i in o._idx}
        r_idx = set(r._idx)
        bound = s_idx ^ r_idx ^ o_idx
        # k-WTA
        if len(bound) > SDR_ACTIVE:
            lst = sorted(bound)
            step = max(1, len(lst) // SDR_ACTIVE)
            bound = set(lst[::step][:SDR_ACTIVE])
        sdr = SparseSDR(bound)
        self._bindings.append((sdr, subj, rel, obj))
        return sdr

    def unbind(self, subj: str, rel: str,
               top_k: int = 3, min_overlap: float = 0.02) -> List[Tuple[float, str]]:
        """Dado sujeito + relação, encontra objetos via XOR reverso."""
        s = self._embed.encode(subj)
        r = self._rel_sdr(rel)
        query = s ^ r
        results = []
        for bound, _, _, b_obj in self._bindings:
            candidate = bound ^ query
            obj_sdr = self._embed.encode(b_obj)
            score = candidate.overlap_score(obj_sdr)
            if score >= min_overlap:
                results.append((score, b_obj))
        return sorted(results, reverse=True)[:top_k]
