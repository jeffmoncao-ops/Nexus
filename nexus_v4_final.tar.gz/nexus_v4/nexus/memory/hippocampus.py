"""
nexus/memory/hippocampus.py — V4
================================
Hipocampo com suporte a CBR (Case-Based Reasoning).

Evoluções em relação ao V3:
  - Colunas action_taken e outcome_score no schema
  - store_case() para casos CBR (problema + ação + resultado)
  - recall_cases() para recuperação geométrica de casos
  - revise_case() para atualizar outcome_score após execução
  - Decaimento Hebbiano diferenciado: casos com outcome < 0.5 decaem 2x mais rápido
  - Soft tags e memory_type preservados do V3
"""
from __future__ import annotations

import asyncio, math, sqlite3, time
from typing import List, Literal, Optional, Tuple

from nexus.core.sdr_math import SparseSDR

RECALL_BOOST         = 0.15
DECAY_RATE           = 0.998
DECAY_RATE_FAILED    = 0.990   # casos com outcome ruim decaem mais rápido
DECAY_FLOOR          = 0.01
INIT_WEIGHT          = 1.0
CONFIDENCE_THRESHOLD = 0.25
RECALL_THRESHOLD     = 0.05
DOMAIN_BOOST         = 0.05
CBR_CONFIDENCE       = 0.40   # threshold para sugerir ação de um caso CBR

MemoryType = Literal["declarative", "procedural", "associative"]


def _infer_memory_type(text: str) -> MemoryType:
    import re as _re
    tokens = set(_re.findall(r'\b\w+\b', text.lower()))
    procedural_kws = {"para", "quando", "entao", "passo", "primeiro", "implemente",
                      "portanto", "logo", "if", "when", "then", "step", "first", "next",
                      "finalmente", "finally", "execute", "compile", "instale"}
    if tokens & procedural_kws:
        return "procedural"
    t = text.lower()
    if any(p in t for p in ["está relacionado", "é semelhante", "assim como", "tal como",
                              "por analogia", "similar a", "is related", "similar to",
                              "just like", "analogous", "such as",
                              "estão relacionados", "estão relacionadas"]):
        return "associative"
    return "declarative"


class Hippocampus:
    """
    Hipocampo V4 com CBR integrado.
    Tabela única — fatos declarativos, procedurais e casos CBR convivem no mesmo espaço.
    """

    def __init__(self, db_path: str = ":memory:"):
        self.db_path = db_path
        self._conn   = sqlite3.connect(db_path, check_same_thread=False)
        self._setup()

    def _setup(self) -> None:
        self._conn.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=NORMAL;

            CREATE TABLE IF NOT EXISTS hippocampus (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                sdr_63bit       INTEGER NOT NULL,
                sdr_blob        BLOB    NOT NULL,
                text_meta       TEXT    NOT NULL DEFAULT '',
                brain_origin    TEXT    NOT NULL DEFAULT 'core',
                memory_type     TEXT    NOT NULL DEFAULT 'declarative',
                action_taken    TEXT,
                outcome_score   REAL    DEFAULT NULL,
                temporal_block  INTEGER NOT NULL,
                weight          REAL    NOT NULL DEFAULT 1.0,
                access_count    INTEGER NOT NULL DEFAULT 0,
                ts              REAL    NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_l1       ON hippocampus(sdr_63bit);
            CREATE INDEX IF NOT EXISTS idx_weight   ON hippocampus(weight DESC);
            CREATE INDEX IF NOT EXISTS idx_brain    ON hippocampus(brain_origin);
            CREATE INDEX IF NOT EXISTS idx_mtype    ON hippocampus(memory_type);
            CREATE INDEX IF NOT EXISTS idx_outcome  ON hippocampus(outcome_score);
            CREATE INDEX IF NOT EXISTS idx_temporal ON hippocampus(temporal_block DESC);
        """)
        self._conn.commit()

    # ── Escrita: fatos genéricos ───────────────────────────────────────────────

    def store(self, sdr: SparseSDR, text: str,
              brain: str = "core",
              weight: float = INIT_WEIGHT,
              memory_type: Optional[MemoryType] = None) -> int:
        existing = self._conn.execute(
            "SELECT id FROM hippocampus WHERE text_meta = ? LIMIT 1", (text,)
        ).fetchone()
        if existing:
            return 0

        mtype = memory_type or _infer_memory_type(text)
        cur   = self._conn.execute(
            "INSERT INTO hippocampus "
            "(sdr_63bit, sdr_blob, text_meta, brain_origin, memory_type, "
            " action_taken, outcome_score, temporal_block, weight, access_count, ts) "
            "VALUES (?, ?, ?, ?, ?, NULL, NULL, ?, ?, 0, ?)",
            (sdr.to_hex_signature(), sdr.to_blob(), text, brain, mtype,
             int(time.time() / 3600), weight, time.time())
        )
        self._conn.commit()
        return cur.lastrowid

    # ── Escrita: casos CBR ─────────────────────────────────────────────────────

    def store_case(self, problem_sdr: SparseSDR,
                   problem_text: str,
                   action: str,
                   outcome_score: float = 0.5,
                   brain: str = "core",
                   weight: float = INIT_WEIGHT) -> int:
        """
        Armazena um caso CBR: problema + ação + resultado.

        problem_text  : descrição da situação/problema
        action        : ação recomendada ou que foi executada
        outcome_score : float [0..1] — 1.0 = sucesso total, 0.0 = falha total
        weight        : casos bem-sucedidos devem ter weight maior
        """
        existing = self._conn.execute(
            "SELECT id FROM hippocampus WHERE text_meta = ? LIMIT 1", (problem_text,)
        ).fetchone()
        if existing:
            return 0

        # Peso inicial proporcional ao outcome
        w = weight * (0.5 + 0.5 * outcome_score)

        cur = self._conn.execute(
            "INSERT INTO hippocampus "
            "(sdr_63bit, sdr_blob, text_meta, brain_origin, memory_type, "
            " action_taken, outcome_score, temporal_block, weight, access_count, ts) "
            "VALUES (?, ?, ?, ?, 'procedural', ?, ?, ?, ?, 0, ?)",
            (problem_sdr.to_hex_signature(), problem_sdr.to_blob(),
             problem_text, brain, action, outcome_score,
             int(time.time() / 3600), w, time.time())
        )
        self._conn.commit()
        return cur.lastrowid

    # ── Leitura: fatos genéricos com soft tags ─────────────────────────────────

    def recall(self, query_sdr: SparseSDR,
               top_k: int = 5,
               preferred_brain: Optional[str] = None,
               preferred_type:  Optional[MemoryType] = None,
               min_jaccard: float = RECALL_THRESHOLD) -> List[Tuple[float, str, str, str]]:
        """
        Retorna (score, text_meta, brain_origin, memory_type).
        Soft boost por preferred_brain e preferred_type.
        Busca no pool inteiro — sem filtro rígido.
        """
        sig63 = query_sdr.to_hex_signature()
        if sig63 == 0:
            return []

        current_block = int(time.time() / 3600)
        rows = self._conn.execute("""
            SELECT id, sdr_blob, text_meta, brain_origin, memory_type,
                   weight, temporal_block, action_taken, outcome_score
            FROM hippocampus
            WHERE (sdr_63bit & ?) > 0
            ORDER BY weight * (1.0 / (1.0 + (? - temporal_block))) DESC
            LIMIT 150
        """, (sig63, current_block)).fetchall()

        if not rows:
            return []

        results: List[Tuple[float, str, str, str]] = []
        for row_id, blob, text, brain, mtype, weight, _, action, outcome in rows:
            if not blob:
                continue
            j = query_sdr.jaccard(SparseSDR.from_blob(blob))
            if j < min_jaccard:
                continue
            score = j * weight
            if preferred_brain and brain == preferred_brain:
                score += DOMAIN_BOOST
            if preferred_type and mtype == preferred_type:
                score += DOMAIN_BOOST * 0.5
            results.append((score, text, brain, mtype))

        results.sort(key=lambda x: -x[0])
        top = results[:top_k]

        for _, text, _, _ in top:
            self._conn.execute("""
                UPDATE hippocampus
                SET weight = MIN(5.0, weight + ?), access_count = access_count + 1
                WHERE text_meta = ?
            """, (RECALL_BOOST, text))
        if top:
            self._conn.commit()

        return top

    # ── Leitura: casos CBR ─────────────────────────────────────────────────────

    def recall_cases(self, problem_sdr: SparseSDR,
                     top_k: int = 3,
                     min_jaccard: float = RECALL_THRESHOLD,
                     min_outcome: float = 0.0) -> List[Tuple[float, str, str, float]]:
        """
        Recupera casos CBR ordenados por (similaridade × peso × outcome).

        Retorna lista de (score, problem_text, action, outcome_score).
        Só retorna casos com outcome_score >= min_outcome.
        """
        sig63 = problem_sdr.to_hex_signature()
        if sig63 == 0:
            return []

        current_block = int(time.time() / 3600)
        rows = self._conn.execute("""
            SELECT id, sdr_blob, text_meta, action_taken, outcome_score, weight, temporal_block
            FROM hippocampus
            WHERE (sdr_63bit & ?) > 0
              AND memory_type = 'procedural'
              AND action_taken IS NOT NULL
              AND outcome_score >= ?
            ORDER BY weight * (1.0 / (1.0 + (? - temporal_block))) DESC
            LIMIT 100
        """, (sig63, min_outcome, current_block)).fetchall()

        if not rows:
            return []

        results: List[Tuple[float, str, str, float]] = []
        for row_id, blob, problem_text, action, outcome, weight, _ in rows:
            if not blob or action is None:
                continue
            j = problem_sdr.jaccard(SparseSDR.from_blob(blob))
            if j < min_jaccard:
                continue
            # Score considera similaridade × peso Hebbiano × outcome
            score = j * weight * (0.5 + 0.5 * (outcome or 0.5))
            results.append((score, problem_text, action, outcome or 0.5))

        results.sort(key=lambda x: -x[0])
        top = results[:top_k]

        # Reforço Hebbiano nos casos recuperados
        for _, problem_text, _, _ in top:
            self._conn.execute("""
                UPDATE hippocampus
                SET weight = MIN(5.0, weight + ?), access_count = access_count + 1
                WHERE text_meta = ? AND memory_type = 'procedural'
            """, (RECALL_BOOST, problem_text))
        if top:
            self._conn.commit()

        return top

    # ── Revisão CBR: atualiza outcome após execução ────────────────────────────

    def revise_case(self, problem_text: str, new_outcome: float) -> bool:
        """
        Revisa o outcome_score de um caso após execução.
        Atualiza o weight proporcional ao novo outcome.
        Retorna True se o caso foi encontrado e atualizado.
        """
        row = self._conn.execute(
            "SELECT id, weight, outcome_score FROM hippocampus "
            "WHERE text_meta = ? AND memory_type = 'procedural' LIMIT 1",
            (problem_text,)
        ).fetchone()

        if not row:
            return False

        cid, old_weight, old_outcome = row
        # Atualiza outcome com média ponderada (novo tem peso 0.7)
        updated_outcome = 0.3 * (old_outcome or 0.5) + 0.7 * new_outcome
        # Ajusta weight: outcomes altos reforçam, baixos enfraquecem
        delta = (new_outcome - 0.5) * 0.3   # [-0.15, +0.15]
        new_weight = max(DECAY_FLOOR, min(5.0, old_weight + delta))

        self._conn.execute("""
            UPDATE hippocampus
            SET outcome_score = ?, weight = ?
            WHERE id = ?
        """, (updated_outcome, new_weight, cid))
        self._conn.commit()
        return True

    # ── Sono Hebbiano diferenciado ─────────────────────────────────────────────

    def sleep_decay(self) -> int:
        """
        Decaimento diferenciado:
        - Casos com outcome_score < 0.5: decaem 2x mais rápido
        - Fatos declarativos e casos bem-sucedidos: decaimento padrão
        """
        # Casos com resultado ruim decaem mais rápido
        cur1 = self._conn.execute("""
            UPDATE hippocampus
            SET weight = MAX(?, weight * ?)
            WHERE memory_type = 'procedural'
              AND outcome_score IS NOT NULL
              AND outcome_score < 0.5
              AND weight > ?
        """, (DECAY_FLOOR, DECAY_RATE_FAILED, DECAY_FLOOR))

        # Demais fatos: decaimento padrão
        cur2 = self._conn.execute("""
            UPDATE hippocampus
            SET weight = MAX(?, weight * ?)
            WHERE NOT (memory_type = 'procedural'
                       AND outcome_score IS NOT NULL
                       AND outcome_score < 0.5)
              AND weight > ?
        """, (DECAY_FLOOR, DECAY_RATE, DECAY_FLOOR))

        self._conn.commit()
        return cur1.rowcount + cur2.rowcount

    # ── Utilitários ────────────────────────────────────────────────────────────

    def best_match(self, query_sdr: SparseSDR,
                   preferred_brain: Optional[str] = None,
                   preferred_type:  Optional[MemoryType] = None) -> Optional[Tuple[float, str, str, str]]:
        hits = self.recall(query_sdr, top_k=1,
                           preferred_brain=preferred_brain,
                           preferred_type=preferred_type)
        return hits[0] if hits else None

    def knows(self, query_sdr: SparseSDR,
              threshold: float = CONFIDENCE_THRESHOLD) -> bool:
        hit = self.best_match(query_sdr)
        return hit is not None and hit[0] >= threshold

    def stats(self) -> dict:
        total    = self._conn.execute("SELECT COUNT(*) FROM hippocampus").fetchone()[0]
        by_brain = dict(self._conn.execute(
            "SELECT brain_origin, COUNT(*) FROM hippocampus GROUP BY brain_origin"
        ).fetchall())
        by_type  = dict(self._conn.execute(
            "SELECT memory_type, COUNT(*) FROM hippocampus GROUP BY memory_type"
        ).fetchall())
        avg_w    = self._conn.execute("SELECT AVG(weight) FROM hippocampus").fetchone()[0] or 0.0
        cbr_cases = self._conn.execute(
            "SELECT COUNT(*), AVG(outcome_score) FROM hippocampus "
            "WHERE memory_type='procedural' AND action_taken IS NOT NULL"
        ).fetchone()
        return {
            "total":       total,
            "by_brain":    by_brain,
            "by_type":     by_type,
            "avg_weight":  round(avg_w, 4),
            "cbr_cases":   cbr_cases[0] or 0,
            "cbr_avg_outcome": round(cbr_cases[1] or 0.0, 4),
        }

    def all_facts(self, brain_filter: Optional[str] = None,
                  type_filter: Optional[MemoryType] = None) -> List[str]:
        conditions, params = [], []
        if brain_filter:
            conditions.append("brain_origin = ?"); params.append(brain_filter)
        if type_filter:
            conditions.append("memory_type = ?");  params.append(type_filter)
        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
        rows  = self._conn.execute(
            f"SELECT text_meta FROM hippocampus {where} ORDER BY ts DESC", params
        ).fetchall()
        return [r[0] for r in rows]

    def raw_select(self, sql: str, params: tuple = ()) -> list:
        return self._conn.execute(sql, params).fetchall()

    def close(self) -> None:
        self._conn.close()


class HippocampusAsync:
    def __init__(self, db_path: str = "nexus_hippocampus.db"):
        self._hip  = Hippocampus(db_path=db_path)
        self._lock = asyncio.Lock()

    async def store(self, sdr: SparseSDR, text: str, brain: str = "core",
                    weight: float = INIT_WEIGHT,
                    memory_type: Optional[MemoryType] = None) -> int:
        async with self._lock:
            return self._hip.store(sdr, text, brain, weight, memory_type)

    async def store_case(self, problem_sdr: SparseSDR, problem_text: str,
                         action: str, outcome_score: float = 0.5,
                         brain: str = "core", weight: float = INIT_WEIGHT) -> int:
        async with self._lock:
            return self._hip.store_case(problem_sdr, problem_text,
                                         action, outcome_score, brain, weight)

    async def recall(self, query_sdr: SparseSDR, top_k: int = 5,
                     preferred_brain: Optional[str] = None,
                     min_jaccard: float = RECALL_THRESHOLD) -> List[Tuple[float, str, str, str]]:
        async with self._lock:
            return self._hip.recall(query_sdr, top_k,
                                     preferred_brain=preferred_brain,
                                     min_jaccard=min_jaccard)

    async def recall_cases(self, problem_sdr: SparseSDR, top_k: int = 3,
                           min_jaccard: float = RECALL_THRESHOLD,
                           min_outcome: float = 0.0) -> List[Tuple[float, str, str, float]]:
        async with self._lock:
            return self._hip.recall_cases(problem_sdr, top_k, min_jaccard, min_outcome)

    async def revise_case(self, problem_text: str, new_outcome: float) -> bool:
        async with self._lock:
            return self._hip.revise_case(problem_text, new_outcome)

    async def knows(self, query_sdr: SparseSDR,
                    threshold: float = CONFIDENCE_THRESHOLD) -> bool:
        async with self._lock:
            return self._hip.knows(query_sdr, threshold)

    async def sleep_decay(self) -> int:
        async with self._lock:
            return self._hip.sleep_decay()

    async def stats(self) -> dict:
        async with self._lock:
            return self._hip.stats()

    def close(self) -> None:
        self._hip.close()
