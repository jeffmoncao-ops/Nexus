# tests/conftest.py
# Fixtures globais definidas em test_nexus_v2.py via @pytest.fixture
