"""
tests/test_nexus_v4.py — Suite completa V4
===========================================
Inclui todos os testes V3 (regressão) + testes CBR completos:
  - store_case / recall_cases com SELECT direto no SQLite
  - Ciclo 4R: Retrieve, Reuse, Revise, Retain
  - Busca geométrica: vocabulário diferente → mesmo caso
  - Decaimento diferenciado: casos ruins decaem mais rápido
  - Import em lote
  - E2E FastAPI: /cases + /cases/solve + /cases/revise
"""
import asyncio, pytest

from nexus.core.sdr_math import (
    SparseSDR, MiniEmbed, XORBinding, VecOps, SDR_SIZE, SDR_ACTIVE, HAS_NUMPY,
)
from nexus.memory.hippocampus import (
    Hippocampus, HippocampusAsync, _infer_memory_type,
    CONFIDENCE_THRESHOLD, RECALL_THRESHOLD, CBR_CONFIDENCE, DOMAIN_BOOST,
)
from nexus.cognitive.brains import GlobalWorkspace, QueryResult, LearnResult
from nexus.cognitive.cbr import CaseEngine, CaseResult
from nexus.cognitive.text_weaver import TextWeaver, WebBrain
from nexus import Nexus


@pytest.fixture
def embed():     return MiniEmbed()
@pytest.fixture
def hip():       return Hippocampus(db_path=":memory:")
@pytest.fixture
def workspace(embed, hip): return GlobalWorkspace(hippocampus=hip, embed=embed)
@pytest.fixture
def engine(hip, embed):    return CaseEngine(hip, embed)
@pytest.fixture
def nexus():     return Nexus(db_path=":memory:", web_enabled=False)


# ══════════════════════════════════════════════════════════════════════════════
# BLOCO 1 — Regressão: SDR, Embed, XOR (V2/V3 mantidos)
# ══════════════════════════════════════════════════════════════════════════════
class TestRegression:

    def test_sdr_bits(self):
        assert len(SparseSDR(list(range(0, 120, 2)))._idx) == 60

    def test_sdr_blob_roundtrip(self):
        o = SparseSDR(list(range(0, 120, 2)))
        assert set(o._idx) == set(SparseSDR.from_blob(o.to_blob())._idx)

    def test_embed_deterministic(self, embed):
        assert set(embed.encode("fotossíntese")._idx) == set(embed.encode("fotossíntese")._idx)

    def test_embed_exact_bits(self, embed):
        assert len(embed.encode("fotossíntese converte luz em glicose")._idx) == SDR_ACTIVE

    def test_xor_directional(self, embed):
        xb = XORBinding(embed)
        b1 = xb.bind("gato","caça","rato"); b2 = xb.bind("rato","caça","gato")
        assert set(b1._idx) != set(b2._idx)

    def test_memory_type_infer_declarative(self):
        assert _infer_memory_type("fotossíntese converte luz em glicose") == "declarative"

    def test_memory_type_infer_procedural(self):
        assert _infer_memory_type("para calcular X, primeiro faça Y") == "procedural"

    def test_memory_type_infer_associative(self):
        assert _infer_memory_type("redes neurais estão relacionadas com neurônios") == "associative"


# ══════════════════════════════════════════════════════════════════════════════
# BLOCO 2 — Hippocampus V4: schema CBR + fatos genéricos
# ══════════════════════════════════════════════════════════════════════════════
class TestHippocampusV4:

    def test_store_generic_fact(self, embed, hip):
        sdr = embed.encode("fotossíntese converte luz em glicose")
        rid = hip.store(sdr, "fotossíntese converte luz em glicose", brain="biologia")
        assert rid > 0

    def test_store_case_returns_rowid(self, embed, hip):
        sdr = embed.encode("temperatura do sensor acima de 80°C")
        rid = hip.store_case(sdr, "temperatura do sensor acima de 80°C",
                              action="ligar sistema de resfriamento",
                              outcome_score=0.95, brain="tecnologia")
        assert rid > 0

    def test_store_case_schema_verified(self, embed, hip):
        """SELECT direto: verifica action_taken e outcome_score no banco."""
        sdr = embed.encode("pressão acima do limite")
        rid = hip.store_case(sdr, "pressão acima do limite",
                              action="acionar válvula de alívio",
                              outcome_score=0.88)
        row = hip.raw_select(
            "SELECT text_meta, action_taken, outcome_score, memory_type "
            "FROM hippocampus WHERE id=?", (rid,)
        )
        assert len(row) == 1
        text, action, outcome, mtype = row[0]
        assert "pressão" in text
        assert action == "acionar válvula de alívio"
        assert abs(outcome - 0.88) < 0.001
        assert mtype == "procedural"

    def test_case_weight_proportional_to_outcome(self, embed, hip):
        """Caso com outcome alto deve ter weight maior que caso com outcome baixo."""
        sdr_good = embed.encode("situação de sucesso total")
        sdr_bad  = embed.encode("situação de falha total diferente")
        rid_good = hip.store_case(sdr_good, "situação de sucesso total",
                                   action="ação A", outcome_score=1.0)
        rid_bad  = hip.store_case(sdr_bad, "situação de falha total diferente",
                                   action="ação B", outcome_score=0.0)

        w_good = hip.raw_select("SELECT weight FROM hippocampus WHERE id=?", (rid_good,))[0][0]
        w_bad  = hip.raw_select("SELECT weight FROM hippocampus WHERE id=?", (rid_bad,))[0][0]
        assert w_good > w_bad, f"w_good={w_good:.3f} w_bad={w_bad:.3f}"

    def test_recall_cases_returns_action(self, embed, hip):
        sdr = embed.encode("temperatura alta demais")
        hip.store_case(sdr, "temperatura alta demais",
                        action="ligar ventilador", outcome_score=0.9)
        hits = hip.recall_cases(embed.encode("sensor de calor elevado"),
                                 top_k=3, min_jaccard=0.01)
        assert len(hits) > 0
        _, problem, action, outcome = hits[0]
        assert action == "ligar ventilador"
        assert outcome == pytest.approx(0.9)

    def test_recall_cases_filters_by_outcome(self, embed, hip):
        """min_outcome filtra casos ruins — busca só os bem-sucedidos."""
        sdr1 = embed.encode("problema A sensor")
        sdr2 = embed.encode("problema B sensor diferente")
        hip.store_case(sdr1, "problema A sensor",   action="ação boa",  outcome_score=0.9)
        hip.store_case(sdr2, "problema B sensor diferente", action="ação ruim", outcome_score=0.1)

        # Com min_outcome=0.5: apenas o caso bom deve aparecer
        hits_filtered = hip.recall_cases(
            embed.encode("sensor problema"),
            top_k=5, min_jaccard=0.01, min_outcome=0.5
        )
        actions = [h[2] for h in hits_filtered]
        assert "ação ruim"  not in actions
        assert "ação boa"   in actions

    def test_revise_case_updates_outcome(self, embed, hip):
        """Após revise, outcome_score deve ser atualizado no banco."""
        sdr = embed.encode("problema para revisão")
        hip.store_case(sdr, "problema para revisão",
                        action="ação X", outcome_score=0.5)

        ok = hip.revise_case("problema para revisão", new_outcome=1.0)
        assert ok is True

        row = hip.raw_select(
            "SELECT outcome_score FROM hippocampus WHERE text_meta=?",
            ("problema para revisão",)
        )
        new_outcome = row[0][0]
        assert new_outcome > 0.5, f"Outcome não foi atualizado: {new_outcome}"

    def test_sleep_decay_failed_cases_faster(self, embed, hip):
        """Casos com outcome < 0.5 devem decair mais rápido."""
        sdr_good = embed.encode("caso de sucesso completo")
        sdr_bad  = embed.encode("caso de falha completa outra")
        hip.store_case(sdr_good, "caso de sucesso completo",
                        action="ação bem-sucedida", outcome_score=1.0)
        hip.store_case(sdr_bad,  "caso de falha completa outra",
                        action="ação fracassada",   outcome_score=0.0)

        # Registro dos weights ANTES do sleep
        w_good_before = hip.raw_select(
            "SELECT weight FROM hippocampus WHERE text_meta=?", ("caso de sucesso completo",)
        )[0][0]
        w_bad_before = hip.raw_select(
            "SELECT weight FROM hippocampus WHERE text_meta=?", ("caso de falha completa outra",)
        )[0][0]

        hip.sleep_decay()

        w_good_after = hip.raw_select(
            "SELECT weight FROM hippocampus WHERE text_meta=?", ("caso de sucesso completo",)
        )[0][0]
        w_bad_after = hip.raw_select(
            "SELECT weight FROM hippocampus WHERE text_meta=?", ("caso de falha completa outra",)
        )[0][0]

        decay_good = w_good_before - w_good_after
        decay_bad  = w_bad_before  - w_bad_after
        assert decay_bad > decay_good, (
            f"Caso ruim deveria decair mais: decay_good={decay_good:.6f} decay_bad={decay_bad:.6f}"
        )

    def test_stats_include_cbr_info(self, embed, hip):
        sdr = embed.encode("caso de teste para stats")
        hip.store_case(sdr, "caso de teste para stats",
                        action="ação de teste", outcome_score=0.7)
        s = hip.stats()
        assert "cbr_cases"       in s
        assert "cbr_avg_outcome" in s
        assert s["cbr_cases"] >= 1
        assert s["cbr_avg_outcome"] > 0


# ══════════════════════════════════════════════════════════════════════════════
# BLOCO 3 — CaseEngine: ciclo 4R completo
# ══════════════════════════════════════════════════════════════════════════════
class TestCaseEngine:

    def test_retain_stores_case(self, engine, hip):
        rid = engine.retain("temperatura do sensor acima de 80°C",
                             action="ligar sistema de resfriamento",
                             outcome_score=0.95)
        assert rid > 0
        row = hip.raw_select(
            "SELECT action_taken, outcome_score FROM hippocampus WHERE id=?", (rid,)
        )
        assert row[0][0] == "ligar sistema de resfriamento"
        assert abs(row[0][1] - 0.95) < 0.001

    def test_retrieve_finds_case(self, engine):
        engine.retain("temperatura do sensor acima de 80°C",
                       action="ligar resfriamento", outcome_score=0.9)
        results = engine.retrieve("sensor de temperatura muito quente", top_k=3)
        assert len(results) > 0
        assert isinstance(results[0], CaseResult)

    def test_geometric_search_different_vocabulary(self, engine):
        """
        TESTE CENTRAL DO CBR GEOMÉTRICO:
        Caso armazenado como "temperatura alta" deve ser encontrado
        com a query "calor excessivo" — vocabulário diferente, vizinhança SDR similar.
        """
        engine.retain("temperatura do sensor acima do limite",
                       action="acionar resfriamento de emergência",
                       outcome_score=0.95)

        # Vocabulário DIFERENTE mas semanticamente próximo
        results = engine.retrieve("calor excessivo sensor disparando alarme",
                                   top_k=3, min_outcome=0.0)
        assert len(results) > 0, (
            "CBR falhou: 'calor excessivo' deveria encontrar caso de 'temperatura alta'. "
            "Geometria SDR não está funcionando como vizinhança."
        )
        actions = [r.action for r in results]
        assert any("resfriamento" in a for a in actions)

    def test_retrieve_and_reuse_returns_confident_result(self, engine):
        engine.retain("pressão hidráulica acima do limite máximo",
                       action="fechar válvula principal imediatamente",
                       outcome_score=0.98, weight=3.0)
        result = engine.retrieve_and_reuse(
            "pressão hidráulica acima do limite máximo"  # query idêntica → confiança máxima
        )
        assert isinstance(result, CaseResult)
        assert result.confident, f"composite_score={result.composite_score:.4f}"
        assert "válvula" in result.action

    def test_retrieve_returns_not_confident_when_empty(self, engine):
        result = engine.retrieve_and_reuse("situação completamente nova e desconhecida xyzzy")
        assert not result.confident
        assert result.action == ""

    def test_revise_updates_outcome(self, engine, hip):
        engine.retain("falha na bomba de combustível",
                       action="desligar motor principal", outcome_score=0.5)
        ok = engine.revise("falha na bomba de combustível", success=True)
        assert ok
        row = hip.raw_select(
            "SELECT outcome_score FROM hippocampus WHERE text_meta=?",
            ("falha na bomba de combustível",)
        )
        assert row[0][0] > 0.5, "Outcome não foi aumentado após revisão positiva"

    def test_revise_penalizes_failed_action(self, engine, hip):
        engine.retain("falha no sistema de freios",
                       action="acionar freio de emergência", outcome_score=0.8)
        engine.revise("falha no sistema de freios", success=False)
        row = hip.raw_select(
            "SELECT outcome_score FROM hippocampus WHERE text_meta=?",
            ("falha no sistema de freios",)
        )
        assert row[0][0] < 0.8, "Outcome não foi reduzido após revisão negativa"

    def test_retain_novelty_blocks_duplicate(self, engine):
        """Caso idêntico não deve ser retido duas vezes."""
        problem = "temperatura acima de 90°C"
        rid1 = engine.retain(problem, action="ação 1", outcome_score=0.9)
        rid2 = engine.retain(problem, action="ação 2", outcome_score=0.9)
        assert rid1 > 0,  "Primeiro retain deve armazenar"
        assert rid2 == 0, "Segundo retain deve ser bloqueado (duplicata)"

    def test_import_cases_batch(self, engine, hip):
        """Importação em lote com relatório."""
        cases = [
            {"problem": "sensor de temperatura disparou",
             "action":  "ligar ventiladores", "outcome": 0.9},
            {"problem": "nível de água abaixo do mínimo",
             "action":  "abrir válvula de entrada", "outcome": 0.85},
            {"problem": "tensão elétrica fora do padrão",
             "action":  "acionar estabilizador", "outcome": 0.7},
        ]
        report = engine.import_cases(cases)
        assert report["imported"] == 3
        assert report["skipped"]  == 0
        assert hip.stats()["cbr_cases"] == 3

    def test_import_skips_duplicates(self, engine):
        cases = [{"problem": "problema único A", "action": "ação A", "outcome": 0.9}]
        engine.import_cases(cases)
        report2 = engine.import_cases(cases)   # segunda vez: tudo duplicata
        assert report2["imported"] == 0
        assert report2["skipped"]  == 1

    def test_case_format_output(self, engine):
        engine.retain("sobrecarga no motor",
                       action="reduzir carga em 50%", outcome_score=0.85)
        result = engine.retrieve_and_reuse("sobrecarga no motor")
        formatted = result.format()
        assert "[CBR]" in formatted
        assert "reduzir carga" in formatted
        assert "%" in formatted

    def test_case_result_not_confident_format(self):
        result = CaseResult(problem_text="", action="", similarity=0.0,
                             outcome_score=0.0, composite_score=0.0, confident=False)
        assert "Nenhum caso" in result.format()


# ══════════════════════════════════════════════════════════════════════════════
# BLOCO 4 — Nexus V4: interface principal com CBR
# ══════════════════════════════════════════════════════════════════════════════
class TestNexusV4:

    def test_learn_case_and_solve(self, nexus):
        nexus.learn_case("temperatura do reator acima de 100°C",
                          action="iniciar protocolo de resfriamento",
                          outcome=0.95)
        result = nexus.solve("temperatura do reator acima de 100°C")
        assert result.confident
        assert "resfriamento" in result.action

    def test_chat_uses_cbr_first(self, nexus):
        """chat() deve usar CBR antes da memória declarativa."""
        nexus.learn_case("alarme de pressão ativado",
                          action="verificar válvulas imediatamente",
                          outcome=0.9)
        response = nexus.chat("alarme de pressão ativado", web_fallback=False)
        assert "[CBR]" in response
        assert "válvulas" in response.lower()

    def test_chat_falls_back_to_declarative(self, nexus):
        """Para perguntas sem ação, usa memória declarativa."""
        nexus.learn("fotossíntese é o processo de conversão de luz em glicose", weight=3.0)
        response = nexus.chat("o que é fotossíntese?", web_fallback=False)
        # Não deve usar CBR (não há ação para "o que é fotossíntese")
        assert "fotossíntese" in response.lower()

    def test_feedback_positive(self, nexus):
        nexus.learn_case("falha no sensor de temperatura", action="reiniciar sensor", outcome=0.5)
        ok = nexus.feedback("falha no sensor de temperatura", success=True)
        assert ok

    def test_import_and_solve(self, nexus):
        report = nexus.import_cases([
            {"problem": "nível de óleo baixo",      "action": "adicionar óleo lubrificante", "outcome": 0.95},
            {"problem": "vibração excessiva motor", "action": "parar e inspecionar",          "outcome": 0.88},
        ])
        assert report["imported"] == 2
        result = nexus.solve("nível de óleo muito baixo")
        assert result.confident or result.action != ""

    def test_health_includes_cbr_stats(self, nexus):
        nexus.learn_case("teste de saúde", action="ação teste", outcome=0.5)
        h = nexus.health()
        assert "cbr" in h
        assert "retrieves" in h["cbr"]

    def test_search_cases(self, nexus):
        nexus.learn_case("sobrecarga elétrica detectada",
                          action="desligar circuito", outcome=0.9)
        results = nexus.search_cases("sobrecarga elétrica", top_k=3)
        assert isinstance(results, list)


# ══════════════════════════════════════════════════════════════════════════════
# BLOCO 5 — GlobalWorkspace V4 (regressão V3)
# ══════════════════════════════════════════════════════════════════════════════
class TestGlobalWorkspaceV4:

    def test_8_brains(self, workspace):
        assert len(workspace._brains) == 8

    def test_shared_hippocampus(self, workspace):
        assert len({id(b._hip) for b in workspace._brains.values()}) == 1

    def test_learn_and_query(self, workspace):
        workspace.learn("teorema de Pitágoras: a²+b²=c²", weight=3.0)
        assert workspace.query("teorema de Pitágoras: a²+b²=c²").confident

    def test_epistemic_state(self, workspace):
        r = workspace.query("supercondutor topológico temperatura zero")
        assert not r.confident and r.score == 0.0

    def test_interdisciplinary_pool(self, workspace):
        workspace.learn("redes neurais artificiais inspiradas nos neurônios do cérebro",
                        brain_id="tecnologia", weight=2.0)
        hits_bio = workspace._brains["biologia"].query("redes neurais neurônio cérebro", top_k=3)
        assert any("redes neurais" in h.text for h in hits_bio)

    def test_memory_type_in_result(self, workspace):
        workspace.learn("DNA carrega informação genética", weight=3.0)
        r = workspace.query("DNA carrega informação genética")
        assert hasattr(r, "memory_type") and r.memory_type != ""


# ══════════════════════════════════════════════════════════════════════════════
# BLOCO 6 — HippocampusAsync V4
# ══════════════════════════════════════════════════════════════════════════════
class TestHippocampusAsyncV4:

    def test_async_store_case_and_recall(self, embed):
        async def _run():
            import tempfile, os
            tmp  = tempfile.mktemp(suffix=".db")
            hipa = HippocampusAsync(db_path=tmp)
            try:
                sdr = embed.encode("temperatura acima do limite")
                rid = await hipa.store_case(sdr, "temperatura acima do limite",
                                             "ativar resfriamento", 0.9, "core")
                assert rid > 0
                hits = await hipa.recall_cases(
                    embed.encode("temperatura limite"), top_k=3
                )
                assert len(hits) > 0
                assert hits[0][2] == "ativar resfriamento"
            finally:
                hipa.close()
                try: os.unlink(tmp)
                except: pass
        asyncio.run(_run())

    def test_async_revise(self, embed):
        async def _run():
            import tempfile, os
            tmp  = tempfile.mktemp(suffix=".db")
            hipa = HippocampusAsync(db_path=tmp)
            try:
                sdr = embed.encode("problema para revisão async")
                await hipa.store_case(sdr, "problema para revisão async",
                                      "ação X", 0.5, "core")
                ok = await hipa.revise_case("problema para revisão async", 1.0)
                assert ok
            finally:
                hipa.close()
                try: os.unlink(tmp)
                except: pass
        asyncio.run(_run())


# ══════════════════════════════════════════════════════════════════════════════
# BLOCO 7 — FastAPI E2E V4: endpoints CBR
# ══════════════════════════════════════════════════════════════════════════════
class TestFastAPIE2E_V4:

    @pytest.fixture(autouse=False)
    def client(self):
        import os, tempfile
        tmp = tempfile.mktemp(suffix=".db")
        os.environ["NEXUS_DB_PATH"] = tmp
        from fastapi.testclient import TestClient
        from nexus.api.server import app
        with TestClient(app) as c:
            yield c
        os.environ.pop("NEXUS_DB_PATH", None)
        try: os.unlink(tmp)
        except: pass

    def test_health_v4(self, client):
        data = client.get("/health").json()
        assert data["version"] == "4.0.0"
        assert "cbr" in data["system"]

    def test_learn_case_endpoint(self, client):
        resp = client.post("/cases", json={
            "problem": "temperatura do motor acima de 100°C",
            "action":  "ligar sistema de resfriamento de emergência",
            "outcome": 0.95,
        })
        data = resp.json()
        assert resp.status_code == 200
        assert data["stored"] is True and data["row_id"] > 0

    def test_solve_confident_after_learn(self, client):
        client.post("/cases", json={
            "problem": "pressão hidráulica acima do limite",
            "action":  "fechar válvula principal",
            "outcome": 0.98,
        })
        resp = client.post("/cases/solve", json={
            "problem":     "pressão hidráulica acima do limite",
            "min_outcome": 0.3,
        })
        data = resp.json()
        assert data["confident"] is True
        assert "válvula" in data["action"]
        assert data["similarity"] > 0
        assert "outcome_score" in data

    def test_solve_not_confident_no_cases(self, client):
        data = client.post("/cases/solve", json={
            "problem": "xyzzy situação completamente desconhecida foobar",
        }).json()
        assert data["confident"] is False

    def test_revise_endpoint(self, client):
        client.post("/cases", json={
            "problem": "falha no sensor de pressão",
            "action":  "reiniciar sensor",
            "outcome": 0.5,
        })
        resp = client.post("/cases/revise", json={
            "problem": "falha no sensor de pressão",
            "success": True,
        })
        assert resp.json()["updated"] is True

    def test_import_batch(self, client):
        resp = client.post("/cases/import", json={"cases": [
            {"problem": "nível de água baixo", "action": "abrir válvula A", "outcome": 0.9},
            {"problem": "tensão fora do padrão", "action": "acionar estabilizador", "outcome": 0.8},
        ]})
        data = resp.json()
        assert data["imported"] == 2 and data["skipped"] == 0

    def test_chat_uses_cbr(self, client):
        client.post("/cases", json={
            "problem": "alarme de temperatura crítica",
            "action":  "acionar protocolo de emergência",
            "outcome": 0.95,
        })
        resp = client.post("/chat", json={
            "message":     "alarme de temperatura crítica",
            "web_fallback": False,
        })
        data = resp.json()
        assert resp.status_code == 200
        assert "[CBR]" in data["response"]
        assert "protocolo" in data["response"].lower()

    def test_full_e2e_pipeline_v4(self, client):
        """Pipeline CBR completo: import → solve → revise → health."""
        # 1. Importa casos
        r1 = client.post("/cases/import", json={"cases": [
            {"problem": "sobrecarga no circuito elétrico",
             "action":  "desligar disjuntor principal", "outcome": 0.92},
            {"problem": "temperatura crítica no servidor",
             "action":  "migrar carga e reiniciar servidor", "outcome": 0.88},
        ]}).json()
        assert r1["imported"] == 2

        # 2. Busca ação
        r2 = client.post("/cases/solve", json={
            "problem": "sobrecarga no circuito elétrico",
        }).json()
        assert r2["confident"]
        assert "disjuntor" in r2["action"]

        # 3. Fornece feedback
        r3 = client.post("/cases/revise", json={
            "problem": "sobrecarga no circuito elétrico",
            "success": True,
        }).json()
        assert r3["updated"]

        # 4. Aprende fato declarativo junto com CBR
        client.post("/learn", json={"text": "disjuntor é dispositivo de proteção elétrica"})

        # 5. Health mostra CBR + fatos
        r5 = client.get("/health").json()
        assert r5["system"]["hippocampus"]["cbr_cases"] >= 2
        assert r5["system"]["hippocampus"]["total"] >= 3
        assert r5["system"]["cbr"]["retains"] >= 2
